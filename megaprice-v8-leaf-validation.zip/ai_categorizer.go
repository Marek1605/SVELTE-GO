package handlers

import (
	"archive/zip"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

// ============================================================
// ADMIN SETTINGS (API keys stored in DB)
// ============================================================

type reportRow struct {
	Title, FeedCat, MatchType, PTitle, CatName, FullPath, Brand, ShopName, Date, CatOrigin, MatchDetail string
	Price float64
}

func (h *Handler) AdminGetAISettings(c *fiber.Ctx) error {
	ctx := context.Background()
	h.db.Pool.Exec(ctx, `CREATE TABLE IF NOT EXISTS admin_settings (key VARCHAR(100) PRIMARY KEY, value TEXT NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`)

	rows, _ := h.db.Pool.Query(ctx, `SELECT key, value FROM admin_settings WHERE key LIKE 'ai_%' OR key LIKE 'openai_%' OR key LIKE 'anthropic_%'`)
	settings := map[string]string{}
	if rows != nil {
		defer rows.Close()
		for rows.Next() {
			var k, v string
			rows.Scan(&k, &v)
			if strings.Contains(k, "api_key") && len(v) > 8 {
				settings[k] = v[:4] + "..." + v[len(v)-4:]
			} else {
				settings[k] = v
			}
		}
	}
	return c.JSON(fiber.Map{"success": true, "data": settings})
}

func (h *Handler) AdminSaveAISettings(c *fiber.Ctx) error {
	ctx := context.Background()
	var input map[string]string
	if err := c.BodyParser(&input); err != nil {
		return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neplatné údaje"})
	}
	h.db.Pool.Exec(ctx, `CREATE TABLE IF NOT EXISTS admin_settings (key VARCHAR(100) PRIMARY KEY, value TEXT NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`)

	allowed := map[string]bool{
		"ai_provider": true, "openai_api_key": true, "anthropic_api_key": true,
		"ai_model_openai": true, "ai_model_anthropic": true,
	}
	for k, v := range input {
		if !allowed[k] { continue }
		// Don't overwrite API keys with masked values (contain "...")
		if strings.Contains(k, "api_key") && strings.Contains(v, "...") {
			continue
		}
		h.db.Pool.Exec(ctx, `INSERT INTO admin_settings (key, value, updated_at) VALUES ($1, $2, NOW()) ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = NOW()`, k, v)
	}
	return c.JSON(fiber.Map{"success": true, "message": "Nastavenia uložené"})
}

func (h *Handler) getAISetting(ctx context.Context, key string) string {
	var value string
	h.db.Pool.QueryRow(ctx, `SELECT value FROM admin_settings WHERE key = $1`, key).Scan(&value)
	return value
}

// ============================================================
// AI KATEGORIZÁCIA V3 — DOKONALÁ LOGIKA (FEED-FIRST)
// ============================================================
//
// FILOZOFIA: Feed kategória = PRAVDA. AI = len pomocník na preklad.
//
// POSTUP:
// 1. Získaj feed kategóriu z ponuky
// 2. NORMALIZUJ feed root → CPC root (mapovacia tabuľka)
// 3. PRIAMY MATCH: Feed cestu namapuj na existujúci strom
//    → Matchne celú cestu → HOTOVO (zadarmo)
//    → Matchne čiastočne → dotvor chýbajúce (zadarmo)
// 4. Root existuje ale vetva nie → vytvor z feed cesty (zadarmo)
// 5. Nič nematchne → AI PRELOŽÍ feed cestu
// 6. POST-AI VALIDÁCIA: root MUSÍ zodpovedať feed doméne
// 7. AI nezmysel → FALLBACK na normalizovanú feed cestu
//
// PRAVIDLO #1: NIKDY nekríži domény!
// PRAVIDLO #2: Feed hierarchia sa VŽDY zachová!
// PRAVIDLO #3: AI len PREKLADÁ, nerozhoduje o štruktúre!
// ============================================================

// ============================================================
// FEED ROOT NORMALIZATION — KOMPLETNÁ MAPOVACIA TABUĽKA
// ============================================================

var feedRootMapping = map[string]string{
	// HRAČKY (vrátane preklepov)
	"speelgoed": "Hry a hračky", "toys": "Hry a hračky", "spielzeug": "Hry a hračky",
	"jouets": "Hry a hračky", "giocattoli": "Hry a hračky", "juguetes": "Hry a hračky",
	"hračky": "Hry a hračky", "hrácky": "Hry a hračky", // preklep v feede!
	"hry": "Hry a hračky", "hry a hračky": "Hry a hračky",
	"detské hračky": "Hry a hračky", "toys & games": "Hry a hračky",
	"speelgoed & spellen": "Hry a hračky",
	// ELEKTRONIKA
	"elektronica": "Elektronika", "electronics": "Elektronika", "elektronika": "Elektronika",
	"elektro": "Elektronika", "consumer electronics": "Elektronika",
	"zvuk": "Elektronika", "audio": "Elektronika", "geluid": "Elektronika",
	"tv": "Elektronika", "televisie": "Elektronika", "video": "Elektronika",
	"foto": "Elektronika", "camera": "Elektronika", "fotografie": "Elektronika",
	"telefóny": "Elektronika", "telefoons": "Elektronika", "phones": "Elektronika",
	// IT / POČÍTAČE
	"computer": "IT", "computers": "IT", "it": "IT", "počítače": "IT",
	"software": "IT", "pc": "IT", "podnikové a serverové produkty": "IT",
	"laptops": "IT", "notebooky": "IT", "tablets": "IT",
	"káble + adaptéry": "IT", "kabels": "IT", "cables": "IT",
	"káble a adaptéry": "IT",
	// BIELA TECHNIKA (práčky, chladničky, umývačky)
	"biela technika": "Biela technika",
	"witgoed": "Biela technika", "white goods": "Biela technika",
	"großgeräte": "Biela technika", "large appliances": "Biela technika",
	"príslušenstvo biela technika": "Biela technika",
	// MALÁ DOMÁCNOSŤ (mixéry, žehličky, vysávače)
	"malá domácnosť": "Malá domácnosť",
	"klein huishoudelijk": "Malá domácnosť", "small appliances": "Malá domácnosť",
	"kleingeräte": "Malá domácnosť",
	// RIAD / KUCHYŇA
	"riad": "Dom a záhrada", "kookgerei": "Dom a záhrada", "cookware": "Dom a záhrada",
	"panvice": "Dom a záhrada", "hrnce": "Dom a záhrada",
	// ČISTENIE
	"čistenie": "Dom a záhrada", "schoonmaak": "Dom a záhrada", "cleaning": "Dom a záhrada",
	"čistiace prostriedky": "Dom a záhrada",
	// PRÍSLUŠENSTVO / DIELY
	"príslušenstvo diely rôzne": "Malá domácnosť",
	// BAZÉNY
	"bazény + príslušenstvo": "Dom a záhrada",
	"bazény": "Dom a záhrada", "zwembaden": "Dom a záhrada",
	// KEMPOVANIE / OUTDOOR
	"kempovanie/voľný čas/nafukovací matrac": "Šport a outdoor",
	"kempovanie": "Šport a outdoor", "camping": "Šport a outdoor",
	// DIEŤA
	"baby": "Dieťa a matka", "baby & peuter": "Dieťa a matka",
	"baby & kleinkind": "Dieťa a matka", "detský tovar": "Dieťa a matka",
	"pre deti": "Dieťa a matka", "dieťa a matka": "Dieťa a matka",
	// OBLEČENIE
	"kleding": "Obuv, oblečenie a doplnky", "clothing": "Obuv, oblečenie a doplnky",
	"fashion": "Obuv, oblečenie a doplnky", "mode": "Obuv, oblečenie a doplnky",
	"oblečenie": "Obuv, oblečenie a doplnky", "obuv": "Obuv, oblečenie a doplnky",
	"schoenen": "Obuv, oblečenie a doplnky", "shoes": "Obuv, oblečenie a doplnky",
	// DOM A ZÁHRADA
	"tuin": "Dom a záhrada", "garden": "Dom a záhrada", "home & garden": "Dom a záhrada",
	"huis": "Dom a záhrada", "wonen": "Dom a záhrada", "home": "Dom a záhrada",
	"dom a záhrada": "Dom a záhrada", "nábytok": "Dom a záhrada",
	"haus & garten": "Dom a záhrada", "kuchyňa": "Dom a záhrada",
	"kúpeľňa": "Dom a záhrada", "badkamer": "Dom a záhrada",
	"osvetlenie": "Dom a záhrada", "verlichting": "Dom a záhrada", "lighting": "Dom a záhrada",
	"úľava": "Dom a záhrada",
	// ZVIERATÁ
	"huisdier": "Pre domáce zvieratá", "dieren": "Pre domáce zvieratá",
	"pets": "Pre domáce zvieratá", "pet supplies": "Pre domáce zvieratá",
	"haustiere": "Pre domáce zvieratá",
	// ŠPORT
	"sport": "Šport a outdoor", "sports": "Šport a outdoor",
	"sport & outdoor": "Šport a outdoor", "outdoor": "Šport a outdoor",
	"fitness": "Šport a outdoor",
	// POTRAVINY
	"food": "Potraviny", "eten & drinken": "Potraviny", "lebensmittel": "Potraviny",
	// ZDRAVIE
	"beauty": "Zdravie a krása", "gezondheid": "Zdravie a krása",
	"health": "Zdravie a krása", "health & beauty": "Zdravie a krása",
	"schoonheid": "Zdravie a krása", "persoonlijke verzorging": "Zdravie a krása",
	// AUTO
	"auto": "Automobilové príslušenstvo", "auto & motor": "Automobilové príslušenstvo",
	"automotive": "Automobilové príslušenstvo", "auto-moto": "Automobilové príslušenstvo",
	// KNIHY A MÉDIÁ
	"boeken": "Knihy a médiá", "books": "Knihy a médiá", "bücher": "Knihy a médiá",
	"media": "Knihy a médiá", "films": "Knihy a médiá",
	// HUDOBNÉ NÁSTROJE (len skutočné nástroje)
	"muziek": "Hudobné nástroje", "music instruments": "Hudobné nástroje",
	"muziekinstrumenten": "Hudobné nástroje",
	// KANCELÁRIA
	"kantoor": "Podnikové a kancelárske potreby", "office": "Podnikové a kancelárske potreby",
	// NÁSTROJE
	"gereedschap": "Nástroje", "tools": "Nástroje", "werkzeug": "Nástroje",
	// SIETE
	"netwerken": "Siete a bezpečnostné systémy", "networking": "Siete a bezpečnostné systémy",
	"bezpečnosť": "Siete a bezpečnostné systémy", "security": "Siete a bezpečnostné systémy",
	"telekomunikácie": "Elektronika", "telecommunicatie": "Elektronika",
	// KANCELÁRIA (rôzne feed formáty)
	"kancelárske potreby / písanie": "Podnikové a kancelárske potreby",
	"kancelárske potreby": "Podnikové a kancelárske potreby",
	"kancelária": "Podnikové a kancelárske potreby",
	"schrijfwaren": "Podnikové a kancelárske potreby",
	// FOTO/VIDEO
	"foto / video": "Elektronika", "fotografia": "Elektronika",
	"televízia / obraz": "Elektronika", "television": "Elektronika",
	// OSOBNÁ STAROSTLIVOSŤ
	"osobná starostlivosť": "Zdravie a krása",
	"personal care": "Zdravie a krása",
	// DETSKÉ POTREBY
	"detské potreby": "Dieťa a matka", "kinderbenodigdheden": "Dieťa a matka",
	// SENIORI
	"seniori a opatrovateľské pomôcky": "Zdravie a krása",
	// ELEKTRO/INŠTALÁCIA
	"elektroinštalačný/spínací/inštalačný materiál": "Dom a záhrada",
	"elektroinstallatie": "Dom a záhrada",
	// GRILOVANIE
	"grilovanie": "Dom a záhrada", "barbecue": "Dom a záhrada", "grillen": "Dom a záhrada",
	// KLIMATIZÁCIA
	"klimatizácia": "Dom a záhrada", "airconditioning": "Dom a záhrada", "klimaat": "Dom a záhrada",
	// KONTROLA HMYZU
	"kontrola hmyzu": "Dom a záhrada", "insectenbestrijding": "Dom a záhrada",
	// HODINY
	"hodiny / budíky": "Dom a záhrada", "hodiny": "Dom a záhrada", "klokken": "Dom a záhrada",
	// ZVIERATÁ (ďalšie formáty)
	"vankúše pre psov + vankúše pre mačky": "Pre domáce zvieratá",
	"potreby pre zvieratá": "Pre domáce zvieratá",
	// PRÍSLUŠENSTVO MOBILY
	"príslušenstvo pre mobilnú komunikáciu": "Elektronika",
	"príslušenstvo kryty puzdrá tašky": "Elektronika",
	"telefoonhoesjes": "Elektronika",
	// DISPLEJE/VEĽKOOBCHOD
	"displeje + balenie vo veľkom": "Obchodné potreby",
	"obchodné články": "Obchodné potreby",
	// AUTOPRÍSLUŠENSTVO (alternatívne)
	"autopríslušenstvo": "Automobilové príslušenstvo",
}

// Sémantické domény — ZAKÁZANÉ kríženie
var categoryDomains = map[string]string{
	// TOYS
	"hry a hračky": "toys", "hračky": "toys", "hry": "toys",
	"spoločenské hry": "toys", "stavebnice": "toys", "bábiky": "toys",
	"vozidlá na odvoz": "toys", "lego": "toys", "puzzle": "toys",
	"speelgoed": "toys", "toys": "toys", "spielzeug": "toys",
	"tractors": "toys", "pešie autá": "toys", "plyšové hračky": "toys",
	"detské hračky": "toys",
	// ELECTRONICS (vrátane audio, slúchadlá, foto, video, TV)
	"elektronika": "electronics", "elektronica": "electronics", "electronics": "electronics",
	"telefón": "electronics", "mobil": "electronics", "tablet": "electronics",
	"notebook": "electronics", "televízia": "electronics", "monitor": "electronics",
	"zvuk": "electronics", "audio": "electronics", "geluid": "electronics",
	"slúchadlá": "electronics", "slúchadlá s mikrofónom": "electronics",
	"reproduktory": "electronics", "luidsprekers": "electronics",
	"foto": "electronics", "camera": "electronics", "fotografie": "electronics",
	"tv": "electronics", "video": "electronics",
	// IT (vrátane periférií, káblov, myší)
	"it": "it", "počítač": "it", "počítače": "it", "computer": "it",
	"server": "it", "softvér": "it",
	"podnikové a serverové produkty": "it",
	"periférie": "it", "myši": "it", "klávesnice": "it",
	"podložky pod myš": "it", "muis matten": "it",
	"káble a adaptéry": "it", "káble + adaptéry": "it", "kabels": "it",
	"tlačiarne": "it", "skenery": "it", "monitory": "it",
	// BABY
	"dieťa a matka": "baby", "detské": "baby", "bábätko": "baby", "kočík": "baby",
	// HOME
	"dom a záhrada": "home", "nábytok": "home", "záhrada": "home", "kuchyňa": "home",
	"kúpeľňa": "home", "osvetlenie": "home", "led lampy": "home",
	"úľava": "home",
	// PETS
	"pre domáce zvieratá": "pets", "krmivo": "pets",
	// SPORT
	"šport a outdoor": "sport", "fitness": "sport", "bicykel": "sport",
	// FASHION
	"oblečenie": "fashion", "obuv, oblečenie a doplnky": "fashion", "obuv": "fashion",
	// AUTO
	"automobilové príslušenstvo": "auto", "auto-moto": "auto",
	// HEALTH
	"zdravie a krása": "health",
	// FOOD
	"potraviny": "food",
	// MUSIC (len skutočné hudobné nástroje!)
	"hudobné nástroje": "music", "gitara": "music", "klavír": "music",
	// NETWORKS (oddelené od IT)
	"siete a bezpečnostné systémy": "networks",
	// BIELA TECHNIKA
	"biela technika": "appliances", "práčka": "appliances", "chladnička": "appliances",
	"umývačka": "appliances", "sušička": "appliances",
	// MALÁ DOMÁCNOSŤ
	"malá domácnosť": "small_appliances", "vysávač": "small_appliances",
	"mixér": "small_appliances", "žehlička": "small_appliances",
	"žehličky": "small_appliances", "žehličky a žehliace systémy": "small_appliances",
	// KANCELÁRIA
	"podnikové a kancelárske potreby": "office", "kancelárske potreby": "office",
	"kancelárske potreby / písanie": "office", "kancelária": "office",
	"papiernictvo": "office", "kalkulačky": "office",
	// OBCHODNÉ
	"obchodné potreby": "business", "obchodné články": "business",
	// SENIORI
	"opatrovateľské pomôcky": "health",
	// BEZPEČNOSŤ
	"bezpečnostné systémy": "networks", "bezpečnosť": "networks",
	// FOTO/VIDEO
	"foto a video": "electronics",
}

func getDomainForName(name string) string {
	lower := strings.ToLower(strings.TrimSpace(name))
	if domain, ok := categoryDomains[lower]; ok { return domain }
	for keyword, domain := range categoryDomains {
		if strings.Contains(lower, keyword) || strings.Contains(keyword, lower) {
			return domain
		}
	}
	return ""
}

// ============================================================
// FEED PARSING + NORMALIZATION
// ============================================================

func parseFeedCategoryPath(feedCategory string) []string {
	var parts []string
	for _, sep := range []string{" | ", " > ", " >> ", " / ", "|", ">", "/"} {
		if strings.Contains(feedCategory, sep) {
			parts = strings.Split(feedCategory, sep)
			break
		}
	}
	if len(parts) == 0 { parts = []string{feedCategory} }
	var cleaned []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" { cleaned = append(cleaned, p) }
	}
	return cleaned
}

func normalizeFeedCategory(feedCategory string) string {
	parts := normalizeFeedParts(feedCategory)
	return strings.Join(parts, " | ")
}

// Preklad bežných podkategórií z cudzích jazykov do slovenčiny
var feedSubCategoryTranslation = map[string]string{
	// HOLANDČINA → SLOVENČINA
	"muis matten": "Podložky pod myš", "muismatten": "Podložky pod myš",
	"muizen": "Myši", "toetsenborden": "Klávesnice",
	"koptelefoons": "Slúchadlá", "headphones": "Slúchadlá", "headsets": "Slúchadlá s mikrofónom",
	"koptelefoons met microfoon": "Slúchadlá s mikrofónom",
	"slúchadlá s mikrofónom": "Slúchadlá s mikrofónom",
	"badkamer accessoires": "Kúpeľňové doplnky", "badkamer": "Kúpeľňa",
	"keuken": "Kuchyňa", "keuken accessoires": "Kuchynské doplnky",
	"verlichting": "Osvetlenie", "led lampen": "LED lampy", "led lampy": "LED lampy",
	"lampen": "Lampy", "speelgoed": "Hračky", "puzzels": "Hádanky",
	"bordspellen": "Spoločenské hry", "kaartspellen": "Kartové hry",
	"actiespellen": "Akčné hry", "akčné hry": "Akčné hry",
	"gezelschapsspellen": "Spoločenské hry", "spellen": "Hry",
	"spoločenské hry a klasické hry": "Spoločenské hry",
	"rôzne hádanky": "Rôzne hádanky",
	"tuin": "Záhrada", "tuingereedschap": "Záhradné náradie",
	"meubels": "Nábytok", "stoelen": "Stoličky", "tafels": "Stoly",
	"kabels": "Káble", "adapters": "Adaptéry", "hdmi": "HDMI",
	"luidsprekers": "Reproduktory", "speakers": "Reproduktory",
	"beeldschermen": "Monitory", "monitors": "Monitory",
	"printers": "Tlačiarne", "scanners": "Skenery",
	"opslag": "Úložiská", "harde schijven": "Pevné disky",
	"netwerkkaarten": "Sieťové karty", "routers": "Routery",
	"accessoires": "Príslušenstvo", "accessories": "Príslušenstvo",
	"zubehör": "Príslušenstvo",
	// ANGLIČTINA → SLOVENČINA
	"mice": "Myši", "keyboards": "Klávesnice", "mouse pads": "Podložky pod myš",
	"cables": "Káble", "chargers": "Nabíjačky",
	"cleaning": "Čistiace prostriedky", "supplies": "Spotrebný materiál",
	"gaming": "Herné", "games": "Hry", "puzzles": "Hádanky",
	"action games": "Akčné hry", "board games": "Spoločenské hry",
	"lighting": "Osvetlenie", "lamps": "Lampy",
	"bathroom": "Kúpeľňa", "kitchen": "Kuchyňa",
	"furniture": "Nábytok", "garden": "Záhrada",
	// RUŽA = zlý preklad holandského "Overig" (= Ostatné/Rôzne)
	"ruža": "Ostatné", "overig": "Ostatné", "overige": "Ostatné",
	"rôzne služby": "Ostatné", "rôzne služobníctvo": "Ostatné", "rôzne": "Ostatné",
	"diversen": "Ostatné", "miscellaneous": "Ostatné", "other": "Ostatné",
	// ĎALŠIE HOLANDSKÉ PREKLADY
	"ijzers": "Žehličky", "strijkijzers": "Žehličky", "stoomstrijkijzer": "Žehličky",
	"železo a systémy": "Žehličky a žehliace systémy", "železa": "Žehličky",
	"stofzuigerzakken": "Vrecká do vysávača", "stofzuigers": "Vysávače",
	"afvalbakken": "Odpadkové koše", "vuilnisbakken": "Odpadkové koše",
	"messen": "Nože", "keukenmessen": "Kuchynské nože",
	"drogers": "Sušičky", "wasdrogers": "Sušičky",
	"geheugenkaarten": "Pamäťové karty", "memory cards": "Pamäťové karty",
	"voicerecorders": "Hlasové záznamníky", "voice recorders": "Hlasové záznamníky",
	// KANCELÁRSKE
	"papierové výrobky": "Papiernictvo", "schrijfwaren": "Písacie potreby",
	"presentatiematerialen": "Prezentačné materiály", "rekenmachines": "Kalkulačky",
	"pennen": "Perá", "potloden": "Ceruzky",
	// ŠPORT/ZÁBAVA
	"buitenspeelgoed": "Vonkajšie hračky", "waterspeelgoed": "Vodné hračky",
	"letná zábava/vodná zábava": "Letná a vodná zábava",
	"strand": "Plážové", "zwemmen": "Plávanie",
	// DEKORÁCIE
	"decoratie": "Dekorácie", "woondecoratie": "Bytová dekorácia",
	"bloemen": "Kvety", "vazen": "Vázy", "kaarsen": "Sviečky",
	// SKLADOVANIE
	"opbergen": "Skladovanie", "opbergboxen": "Úložné boxy",
}

func normalizeFeedParts(feedCategory string) []string {
	parts := parseFeedCategoryPath(feedCategory)
	if len(parts) == 0 { return parts }

	// Preklad ROOT
	rootLower := strings.ToLower(strings.TrimSpace(parts[0]))
	if mappedRoot, ok := feedRootMapping[rootLower]; ok {
		originalRoot := parts[0]
		parts[0] = mappedRoot

		// Ak root mapping zmenšil špecifickosť, zachovaj pôvodný root ako sub
		// Napr: "Foto / Video" → "Elektronika" + "Foto a Video"
		// Napr: "Televízia / Obraz" → "Elektronika" + "Televízia"
		rootPreserveMap := map[string]string{
			// Dom a záhrada subkategórie
			"riad":                "Riad",
			"kookgerei":           "Riad",
			"cookware":            "Riad",
			"panvice":             "Panvice",
			"hrnce":               "Hrnce",
			"čistenie":            "Čistenie",
			"schoonmaak":          "Čistenie",
			"cleaning":            "Čistenie",
			"čistiace prostriedky": "Čistiace prostriedky",
			"bazény + príslušenstvo": "Bazény",
			"bazény":              "Bazény",
			"zwembaden":           "Bazény",
			"nábytok":             "Nábytok",
			"kuchyňa":             "Kuchyňa",
			"kúpeľňa":             "Kúpeľňa",
			"badkamer":            "Kúpeľňa",
			"osvetlenie":          "Osvetlenie",
			"verlichting":         "Osvetlenie",
			"lighting":            "Osvetlenie",
			"grilovanie":          "Grilovanie",
			"barbecue":            "Grilovanie",
			"grillen":             "Grilovanie",
			"klimatizácia":        "Klimatizácia",
			"airconditioning":     "Klimatizácia",
			"kontrola hmyzu":      "Kontrola hmyzu",
			"hodiny / budíky":     "Hodiny a budíky",
			"hodiny":              "Hodiny a budíky",
			"klokken":             "Hodiny a budíky",
			"úľava":               "Osvetlenie",
			"elektroinštalačný/spínací/inštalačný materiál": "Elektroinštalácie",
			"elektroinstallatie":  "Elektroinštalácie",
			// Elektronika subkategórie
			"foto / video":        "Foto a Video",
			"televízia / obraz":   "Televízia",
			"zvuk":                "Audio",
			"audio":               "Audio",
			"geluid":              "Audio",
			"telefóny":            "Telefóny",
			"telefoons":           "Telefóny",
			"phones":              "Telefóny",
			"tv":                  "Televízia",
			"televisie":           "Televízia",
			"video":               "Video",
			"foto":                "Foto",
			"camera":              "Foto",
			"fotografie":          "Foto",
			"príslušenstvo pre mobilnú komunikáciu": "Príslušenstvo pre mobily",
			"príslušenstvo kryty puzdrá tašky": "Obaly a puzdrá",
			"telekomunikácie":     "Telekomunikácie",
			"telecommunicatie":    "Telekomunikácie",
			// IT subkategórie
			"káble + adaptéry":    "Káble a adaptéry",
			"káble a adaptéry":    "Káble a adaptéry",
			"kabels":              "Káble a adaptéry",
			"cables":              "Káble a adaptéry",
			"podnikové a serverové produkty": "Servery",
			// Zdravie subkategórie
			"osobná starostlivosť": "Osobná starostlivosť",
			"persoonlijke verzorging": "Osobná starostlivosť",
			"personal care":       "Osobná starostlivosť",
			"seniori a opatrovateľské pomôcky": "Opatrovateľské pomôcky",
			// Bezpečnosť
			"bezpečnosť":          "Bezpečnostné systémy",
			"security":            "Bezpečnostné systémy",
			// Dieťa
			"detské potreby":      "Detské potreby",
			"kinderbenodigdheden": "Detské potreby",
			// Šport
			"kempovanie":          "Kempovanie",
			"camping":             "Kempovanie",
			"kempovanie/voľný čas/nafukovací matrac": "Kempovanie",
			"fitness":             "Fitness",
			// Zvieratá
			"vankúše pre psov + vankúše pre mačky": "Posteľné vankúše",
			"potreby pre zvieratá": "Potreby pre zvieratá",
			// Obchod
			"displeje + balenie vo veľkom": "Veľkoobchod",
			"obchodné články":     "Obchodné články",
			// Príslušenstvo
			"príslušenstvo diely rôzne": "Príslušenstvo a diely",
			// Auto
			"autopríslušenstvo":   "Autopríslušenstvo",
		}
		origLower := strings.ToLower(strings.TrimSpace(originalRoot))
		if subName, ok := rootPreserveMap[origLower]; ok && !strings.EqualFold(mappedRoot, originalRoot) {
			// Vlož podkategóriu hneď za root
			newParts := []string{mappedRoot, subName}
			newParts = append(newParts, parts[1:]...)
			parts = newParts
		}
	}

	// Preklad SUB-KATEGÓRIÍ (zachovaj špecifickosť!)
	for i := 1; i < len(parts); i++ {
		subLower := strings.ToLower(strings.TrimSpace(parts[i]))
		if translated, ok := feedSubCategoryTranslation[subLower]; ok {
			parts[i] = translated
		}
	}

	return parts
}

// ============================================================
// BULK AI CATEGORIZATION
// ============================================================

func (h *Handler) AdminAIBulkCategorizeStart(c *fiber.Ctx) error {
	ctx := context.Background()
	var input struct {
		ShopID          string `json:"shop_id"`
		Mode            string `json:"mode"` // "fast", "precise", "ultra", "creative", "smart", "smart_create"
		Continue        bool   `json:"continue_from_last"`
		UseDescriptions bool   `json:"use_descriptions"`
	}
	c.BodyParser(&input)
	if input.Mode == "" { input.Mode = "fast" }
	isCreative := input.Mode == "creative"

	provider := h.getAISetting(ctx, "ai_provider")
	if provider == "" { provider = "openai" }
	model := h.getActiveModel(ctx, provider)
	var apiKey string
	if provider == "openai" { apiKey = h.getAISetting(ctx, "openai_api_key") } else { apiKey = h.getAISetting(ctx, "anthropic_api_key") }
	if apiKey == "" { return c.Status(400).JSON(fiber.Map{"success": false, "error": "API kľúč nie je nastavený."}) }

	var runningCount int
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM ai_categorization_jobs WHERE status = 'running'`).Scan(&runningCount)
	if runningCount > 0 { return c.Status(409).JSON(fiber.Map{"success": false, "error": "Kategorizácia už prebieha"}) }

	// If NOT continuing, reset previously failed/unmatched offers
	if !input.Continue {
		if isCreative {
			// Kreatívna: NERESETOVAŤ ai_unmatched — tie sú vstup pre kreatívnu!
		} else {
			if input.ShopID != "" {
				h.db.Pool.Exec(ctx, `UPDATE offers SET match_type = NULL WHERE product_id IS NULL AND match_type IN ('ai_failed', 'ai_unmatched') AND shop_id = $1`, input.ShopID)
			} else {
				h.db.Pool.Exec(ctx, `UPDATE offers SET match_type = NULL WHERE product_id IS NULL AND match_type IN ('ai_failed', 'ai_unmatched')`)
			}
		}
	}

	var uncategorizedCount int
	var unmatchedOffersCount int
	var failedCount int
	if input.ShopID != "" {
		h.db.Pool.QueryRow(ctx, `SELECT COUNT(DISTINCT p.id) FROM products p INNER JOIN offers o ON o.product_id = p.id WHERE p.category_id IS NULL AND o.shop_id = $1`, input.ShopID).Scan(&uncategorizedCount)
		if isCreative {
			h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND match_type = 'ai_unmatched' AND shop_id = $1`, input.ShopID).Scan(&unmatchedOffersCount)
		} else {
			h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND (match_type IS NULL OR match_type = 'unmatched') AND shop_id = $1`, input.ShopID).Scan(&unmatchedOffersCount)
		}
		h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND match_type = 'ai_unmatched' AND shop_id = $1`, input.ShopID).Scan(&failedCount)
	} else {
		h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM products WHERE category_id IS NULL`).Scan(&uncategorizedCount)
		if isCreative {
			h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND match_type = 'ai_unmatched'`).Scan(&unmatchedOffersCount)
		} else {
			h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND (match_type IS NULL OR match_type = 'unmatched')`).Scan(&unmatchedOffersCount)
		}
		h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND match_type = 'ai_unmatched'`).Scan(&failedCount)
	}
	totalToProcess := uncategorizedCount + unmatchedOffersCount
	if totalToProcess == 0 && !isCreative { return c.JSON(fiber.Map{"success": true, "message": "Všetky produkty už majú kategóriu a žiadne nenapárované ponuky", "unmatched": 0}) }
	if totalToProcess == 0 && isCreative { return c.JSON(fiber.Map{"success": true, "message": "Žiadne nezaradené ponuky na kreatívnu kategorizáciu. Najprv spusti Smart alebo Presnú.", "unmatched": 0}) }

	h.db.Pool.Exec(ctx, `CREATE TABLE IF NOT EXISTS ai_categorization_jobs (
		id UUID PRIMARY KEY DEFAULT gen_random_uuid(), status VARCHAR(20) DEFAULT 'pending',
		provider VARCHAR(20) DEFAULT 'openai', total_offers INT DEFAULT 0,
		processed INT DEFAULT 0, matched INT DEFAULT 0, new_products INT DEFAULT 0,
		new_categories INT DEFAULT 0, errors INT DEFAULT 0, error_log TEXT,
		started_at TIMESTAMP, finished_at TIMESTAMP, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`)

	jobID := uuid.New()
	modeLabel := "⚡ Rýchla"
	if input.Mode == "precise" { modeLabel = "🎯 Presná" }
	if input.Mode == "ultra" { modeLabel = "🔬 Veľmi presná" }
	if input.Mode == "creative" { modeLabel = "🆕 Kreatívna" }
	if input.Mode == "smart" { modeLabel = "💡 Smart (presná + lacná)" }
	if input.Mode == "smart_create" { modeLabel = "💡+ Smart+ (vytvára podkategórie)" }
	h.db.Pool.Exec(ctx, `INSERT INTO ai_categorization_jobs (id, status, provider, total_offers, started_at) VALUES ($1, 'running', $2, $3, NOW())`, jobID, provider, totalToProcess)
	go h.runBulkCategorization(jobID, provider, apiKey, input.ShopID, input.Mode, input.UseDescriptions)

	continueMsg := ""
	if input.Continue && failedCount > 0 {
		continueMsg = fmt.Sprintf(" (preskočených %d predtým zlyhanych)", failedCount)
	}
	return c.JSON(fiber.Map{"success": true, "job_id": jobID, "unmatched": totalToProcess, "mode": input.Mode,
		"provider": provider, "model": model, "failed_skipped": failedCount,
		"message": fmt.Sprintf("%s kategorizácia spustená — %d produktov + %d ponúk%s | %s/%s", modeLabel, uncategorizedCount, unmatchedOffersCount, continueMsg, provider, model)})
}

func (h *Handler) AdminAIBulkCategorizeProgress(c *fiber.Ctx) error {
	ctx := context.Background()
	var job struct {
		ID, Status, Provider string
		TotalOffers, Processed, Matched, NewProducts, NewCategories, Errors int
		ErrorLog, StartedAt, FinishedAt *string
	}
	err := h.db.Pool.QueryRow(ctx, `SELECT id, status, provider, total_offers, processed, matched, new_products, new_categories, errors, error_log, started_at::text, finished_at::text FROM ai_categorization_jobs ORDER BY created_at DESC LIMIT 1`).Scan(
		&job.ID, &job.Status, &job.Provider, &job.TotalOffers, &job.Processed, &job.Matched, &job.NewProducts, &job.NewCategories, &job.Errors, &job.ErrorLog, &job.StartedAt, &job.FinishedAt)
	if err != nil { return c.JSON(fiber.Map{"success": true, "data": nil, "message": "Žiadna kategorizácia zatiaľ"}) }
	percent := 0
	if job.TotalOffers > 0 { percent = (job.Processed * 100) / job.TotalOffers }

	// Get active provider/model for display
	activeProvider := h.getAISetting(ctx, "ai_provider")
	if activeProvider == "" { activeProvider = "openai" }
	activeModel := h.getActiveModel(ctx, activeProvider)
	// Count remaining unprocessed, unmatched (awaiting Creative), and cache
	var remainingCount, unmatchedCount, cacheCount int
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND (match_type IS NULL OR match_type = 'unmatched')`).Scan(&remainingCount)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL AND match_type = 'ai_unmatched'`).Scan(&unmatchedCount)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM feed_category_cache`).Scan(&cacheCount)

	return c.JSON(fiber.Map{"success": true, "data": fiber.Map{
		"id": job.ID, "status": job.Status, "provider": job.Provider,
		"total_offers": job.TotalOffers, "processed": job.Processed, "matched": job.Matched,
		"new_products": job.NewProducts, "new_categories": job.NewCategories, "errors": job.Errors,
		"error_log": job.ErrorLog, "percent": percent,
		"started_at": job.StartedAt, "finished_at": job.FinishedAt,
		"active_provider": activeProvider, "active_model": activeModel,
		"remaining": remainingCount, "failed": unmatchedCount, "unmatched": unmatchedCount, "cache_count": cacheCount}})
}

func (h *Handler) AdminAIBulkCategorizeCancel(c *fiber.Ctx) error {
	ctx := context.Background()
	h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET status = 'cancelled', finished_at = NOW() WHERE status = 'running'`)
	return c.JSON(fiber.Map{"success": true, "message": "Kategorizácia zastavená"})
}

// AdminAIClearCache — vyčistí feed_category_cache tabuľku
func (h *Handler) AdminAIClearCache(c *fiber.Ctx) error {
	ctx := context.Background()
	res, _ := h.db.Pool.Exec(ctx, `DELETE FROM feed_category_cache`)
	count := res.RowsAffected()
	return c.JSON(fiber.Map{"success": true, "message": fmt.Sprintf("Vymazaných %d cache záznamov", count)})
}

// ============================================================
// HLAVNÁ LOGIKA V3 — FEED-FIRST
// ============================================================

func (h *Handler) runBulkCategorization(jobID uuid.UUID, provider, apiKey, shopID string, mode string, useDescriptions bool) {
	ctx := context.Background()
	h.db.Pool.Exec(ctx, `ALTER TABLE categories ADD COLUMN IF NOT EXISTS created_by_shop_id UUID REFERENCES shops(id) ON DELETE SET NULL`)
	h.db.Pool.Exec(ctx, `ALTER TABLE offers ADD COLUMN IF NOT EXISTS image TEXT`)
	h.db.Pool.Exec(ctx, `ALTER TABLE offers ADD COLUMN IF NOT EXISTS ai_suggested_category TEXT`)

	model := h.getActiveModel(ctx, provider)
	batchSize := 20
	totalProcessed, totalCategorized, totalNewCats, totalErrors, totalNewProducts := 0, 0, 0, 0, 0
	totalAIVerified, totalAICorrected := 0, 0
	var errorLogs []string

	// FEED CACHE — rovnaká feed kategória = rovnaký výsledok (šetrí API calls)
	feedCategoryCache := make(map[string]string) // feedCategory → categoryID

	isPrecise := mode == "precise"
	isUltra := mode == "ultra"
	isCreative := mode == "creative"
	isSmart := mode == "smart"
	isSmartCreate := mode == "smart_create"

	// Initialize persistent DB cache
	h.initFeedCategoryCache(ctx)

	// Pre-load DB cache into memory
	dbCacheRows, _ := h.db.Pool.Query(ctx, `SELECT feed_category, category_id FROM feed_category_cache`)
	if dbCacheRows != nil {
		for dbCacheRows.Next() {
			var fc, cid string
			dbCacheRows.Scan(&fc, &cid)
			feedCategoryCache[fc] = cid
		}
		dbCacheRows.Close()
	}
	dbCacheLoaded := len(feedCategoryCache)

	addError := func(msg string) {
		totalErrors++
		errorLogs = append(errorLogs, fmt.Sprintf("[%s] ❌ %s", time.Now().Format("15:04:05"), msg))
		logStr := strings.Join(errorLogs, "\n")
		if len(logStr) > 10000 { logStr = logStr[len(logStr)-10000:] }
		h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET errors = $1, error_log = $2 WHERE id = $3`, totalErrors, logStr, jobID)
	}
	addLog := func(msg string) {
		errorLogs = append(errorLogs, fmt.Sprintf("[%s] %s", time.Now().Format("15:04:05"), msg))
		logStr := strings.Join(errorLogs, "\n")
		if len(logStr) > 10000 { logStr = logStr[len(logStr)-10000:] }
		h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET error_log = $1 WHERE id = $2`, logStr, jobID)
	}

	modeLabel := "⚡ Rýchla"
	if isPrecise { modeLabel = "🎯 Presná" }
	if isUltra { modeLabel = "🔬 Veľmi presná" }
	if isCreative { modeLabel = "🆕 Kreatívna" }
	if isSmart { modeLabel = "💡 Smart" }
	if isSmartCreate { modeLabel = "💡+ Smart+ (vytvára podkategórie)" }
	descLabel := ""
	if useDescriptions { descLabel = " + popisy" }
	addLog(fmt.Sprintf("🚀 Štart AI kategorizácie V3 (%s%s), provider: %s, model: %s", modeLabel, descLabel, provider, model))
	if dbCacheLoaded > 0 {
		addLog(fmt.Sprintf("💾 Načítaných %d feed→kategória z DB cache", dbCacheLoaded))
	}
	// Log tree size
	initTree := h.getExistingCategoryTree(ctx)
	treeCtx := buildCategoryTreeContext(initTree)
	addLog(fmt.Sprintf("🌳 Strom: %d kategórií, %d riadkov v AI kontexte", len(initTree), len(strings.Split(treeCtx, "\n"))))

	for {
		var status string
		h.db.Pool.QueryRow(ctx, `SELECT status FROM ai_categorization_jobs WHERE id = $1`, jobID).Scan(&status)
		if status != "running" { addLog("⏹ Zastavená"); return }

		var queryStr string
		var queryArgs []interface{}
		if shopID != "" {
			queryStr = `SELECT DISTINCT p.id, p.title, COALESCE(p.description,''), COALESCE(p.ean,''), COALESCE(p.brand,'') FROM products p INNER JOIN offers o ON o.product_id = p.id WHERE p.category_id IS NULL AND o.shop_id = $2 ORDER BY p.title ASC LIMIT $1`
			queryArgs = []interface{}{batchSize, shopID}
		} else {
			queryStr = `SELECT p.id, p.title, COALESCE(p.description,''), COALESCE(p.ean,''), COALESCE(p.brand,'') FROM products p WHERE p.category_id IS NULL ORDER BY p.title ASC LIMIT $1`
			queryArgs = []interface{}{batchSize}
		}

		rows, err := h.db.Pool.Query(ctx, queryStr, queryArgs...)
		if err != nil {
			addError(fmt.Sprintf("Query error: %v", err))
			h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET status = 'error', finished_at = NOW() WHERE id = $1`, jobID)
			return
		}

		type productItem struct { ID, Title, Description, EAN, Brand string }
		var batch []productItem
		for rows.Next() {
			var item productItem
			rows.Scan(&item.ID, &item.Title, &item.Description, &item.EAN, &item.Brand)
			batch = append(batch, item)
		}
		rows.Close()
		if len(batch) == 0 { addLog("✅ Všetky produkty spracované"); break }

		addLog(fmt.Sprintf("📦 Batch %d produktov (celkom: %d)", len(batch), totalProcessed))
		existingCategories := h.getExistingCategoryTree(ctx)

		for _, product := range batch {
			totalProcessed++
			feedCategory := h.getFeedCategoryForProduct(ctx, product.ID)
			var categoryID string
			var wasNewCategory bool
			var method string

			if isUltra || isCreative {
				// === ULTRA/KREATÍVNY MÓD — AI V3 s plným kontextom ===
				feedCategory := h.getFeedCategoryForProduct(ctx, product.ID)
				feedParts := normalizeFeedParts(feedCategory)
				// V ultra móde vždy volá AI, aj keď je feed match
				aiResult, aiErr := h.aiCategorizeV3(provider, apiKey, model, product.Title, feedCategory, feedParts, product.Description, existingCategories)
				if aiErr != nil {
					addError(fmt.Sprintf("Ultra AI error: '%s': %v", truncateTitle(product.Title, 40), aiErr))
				}
				if aiResult != nil && len(aiResult.CategoryPath) > 0 {
					validatedPath := validateCategoryPathV3(aiResult.CategoryPath, feedParts)
					categoryID = h.findCategoryForMode(ctx, validatedPath, isCreative, &existingCategories, shopID)
					method = "🔬 AI Ultra"; if isCreative { method = "🆕 AI Kreatívna" }
					if aiResult.Brand != "" && product.Brand == "" {
						h.db.Pool.Exec(ctx, `UPDATE products SET brand = $1 WHERE id = $2 AND (brand IS NULL OR brand = '')`, aiResult.Brand, product.ID)
					}
				} else if feedCategory != "" {
					categoryID = h.findCategoryForMode(ctx, feedParts, isCreative, &existingCategories, shopID)
					method = "📁 Feed fallback"
				}
				time.Sleep(300 * time.Millisecond)
			} else if feedCategory != "" {
				feedParts := normalizeFeedParts(feedCategory)

				// FEED CACHE CHECK — ak sme už túto feed kategóriu spracovali, použi cache
				if cachedCatID, ok := feedCategoryCache[feedCategory]; ok {
					categoryID = cachedCatID
					method = "💾 Cache"
				} else {
					// KROK 1: PRIAMY MATCH (celá cesta existuje v strome)
					catID := h.matchFeedPathToTree(ctx, feedParts, existingCategories, shopID)

					if catID != "" && !isPrecise {
						// === RÝCHLY REŽIM — feed match = hotovo ===
						categoryID = catID
						method = "📁 Feed match"
					} else if catID != "" && isPrecise {
						// === PRESNÝ REŽIM — AI verifikuje feed match ===
						existingPath := h.buildCategoryPath(ctx, catID)
						verifyResult, verifyErr := h.aiVerifyCategory(provider, apiKey, model, product.Title, feedCategory, existingPath, existingCategories)
						if verifyErr != nil || verifyResult == nil {
							// AI nedostupné — použi feed match ako fallback
							categoryID = catID
							method = "📁 Feed match (AI nedostupné)"
						} else if verifyResult.IsCorrect {
							// AI potvrdilo — feed match je správny
							categoryID = catID
							method = "✅ AI potvrdené"
							totalAIVerified++
						} else if len(verifyResult.BetterPath) > 0 {
							// AI navrhlo lepšiu cestu
							validatedPath := validateCategoryPathV3(verifyResult.BetterPath, feedParts)
							categoryID = h.findCategoryForMode(ctx, validatedPath, isCreative, &existingCategories, shopID)
							wasNewCategory = isCreative
							method = "🔄 AI opravené"
							totalAICorrected++
						} else {
							categoryID = catID
							method = "📁 Feed match"
						}
						time.Sleep(200 * time.Millisecond)
					} else {
						// KROK 2: AI KATEGORIZÁCIA (feed match neexistuje)
						aiResult, aiErr := h.aiCategorizeV3(provider, apiKey, model, product.Title, feedCategory, feedParts, "", existingCategories)
						if aiErr != nil || aiResult == nil || len(aiResult.CategoryPath) == 0 {
							// KROK 3: FALLBACK — hľadaj existujúcu, NEVYTVÁRAJ
							categoryID = h.findCategoryForMode(ctx, feedParts, isCreative, &existingCategories, shopID)
							method = "📁 Feed fallback (existujúca)"
							if aiErr != nil { addError(fmt.Sprintf("AI error (fallback): '%s': %v", truncateTitle(product.Title, 40), aiErr)) }
						} else {
							validatedPath := validateCategoryPathV3(aiResult.CategoryPath, feedParts)
							categoryID = h.findCategoryForMode(ctx, validatedPath, isCreative, &existingCategories, shopID)
							method = "🤖 AI"
							if aiResult.Brand != "" && product.Brand == "" {
								h.db.Pool.Exec(ctx, `UPDATE products SET brand = $1 WHERE id = $2 AND (brand IS NULL OR brand = '')`, aiResult.Brand, product.ID)
							}
						}
					}

					// Ulož do cache
					if categoryID != "" { feedCategoryCache[feedCategory] = categoryID }
				}
			} else {
				// ŽIADNA FEED KATEGÓRIA
				desc := product.Description
				if len(desc) > 500 { desc = desc[:500] }
				aiResult, aiErr := h.aiCategorizeV3(provider, apiKey, model, product.Title, "", nil, desc, existingCategories)
				if aiErr != nil { addError(fmt.Sprintf("AI error: '%s': %v", truncateTitle(product.Title, 40), aiErr)); h.updateJobStats(ctx, jobID, totalProcessed, totalCategorized, 0, totalNewCats, totalErrors); continue }
				if aiResult == nil || len(aiResult.CategoryPath) == 0 { addError(fmt.Sprintf("AI prázdny: '%s'", truncateTitle(product.Title, 40))); h.updateJobStats(ctx, jobID, totalProcessed, totalCategorized, 0, totalNewCats, totalErrors); continue }
				categoryID = h.findCategoryForMode(ctx, aiResult.CategoryPath, isCreative, &existingCategories, shopID)
				wasNewCategory = aiResult.CreatedNewCategory
				method = "🤖 AI (len názov)"
				if aiResult.Brand != "" && product.Brand == "" {
					h.db.Pool.Exec(ctx, `UPDATE products SET brand = $1 WHERE id = $2 AND (brand IS NULL OR brand = '')`, aiResult.Brand, product.ID)
				}
				time.Sleep(300 * time.Millisecond)
			}

			if categoryID != "" {
				_, updateErr := h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1, updated_at = NOW() WHERE id = $2`, categoryID, product.ID)
				if updateErr != nil {
					addError(fmt.Sprintf("Update error: '%s': %v", truncateTitle(product.Title, 40), updateErr))
				} else {
					totalCategorized++
					if wasNewCategory { totalNewCats++ }
					path := h.buildCategoryPath(ctx, categoryID)
					addLog(fmt.Sprintf("%s: \"%s\" → %s", method, truncateTitle(product.Title, 40), path))
				}
			}
			h.updateJobStats(ctx, jobID, totalProcessed, totalCategorized, 0, totalNewCats, totalErrors)
		}
	}

	// ============================================================
	// FÁZA 2: Nenapárované ponuky (offers bez product_id)
	// Pre každú: vytvor produkt + zaraď AI kategóriou
	// ============================================================
	addLog("📋 Fáza 2: Spracovanie nenapárovaných ponúk...")
	var lastBatchFirstID string
	var repeatCount int

	for {
		var status string
		h.db.Pool.QueryRow(ctx, `SELECT status FROM ai_categorization_jobs WHERE id = $1`, jobID).Scan(&status)
		if status != "running" { addLog("⏹ Zastavená"); break }

		var offerQuery string
		var offerArgs []interface{}
		
		// Kreatívna: spracúva IBA ai_unmatched (z predošlej kategorizácie)
		// Ostatné: spracúvajú nové/nesparované offers
		matchFilter := `(match_type IS NULL OR match_type = 'unmatched')`
		if isCreative {
			matchFilter = `match_type = 'ai_unmatched'`
		}
		
		if shopID != "" {
			offerQuery = fmt.Sprintf(`SELECT id, title, COALESCE(description,''), COALESCE(ean,''), COALESCE(category,''), price, shop_id, COALESCE(image,''), COALESCE(ai_suggested_category,'') FROM offers WHERE product_id IS NULL AND %s AND shop_id = $2 ORDER BY title ASC LIMIT $1`, matchFilter)
			offerArgs = []interface{}{batchSize, shopID}
		} else {
			offerQuery = fmt.Sprintf(`SELECT id, title, COALESCE(description,''), COALESCE(ean,''), COALESCE(category,''), price, shop_id, COALESCE(image,''), COALESCE(ai_suggested_category,'') FROM offers WHERE product_id IS NULL AND %s ORDER BY title ASC LIMIT $1`, matchFilter)
			offerArgs = []interface{}{batchSize}
		}

		oRows, oErr := h.db.Pool.Query(ctx, offerQuery, offerArgs...)
		if oErr != nil { addError(fmt.Sprintf("Offer query error: %v", oErr)); break }

		type offerItem = offerItemForProduct
		var offerBatch []offerItem
		for oRows.Next() {
			var o offerItem
			oRows.Scan(&o.ID, &o.Title, &o.Description, &o.EAN, &o.Category, &o.Price, &o.ShopID, &o.Image, &o.AISuggestedCategory)
			offerBatch = append(offerBatch, o)
		}
		oRows.Close()
		if len(offerBatch) == 0 { addLog("✅ Všetky ponuky spracované"); break }

		// Loop detection — ak sa batch opakuje, zastav
		if len(offerBatch) > 0 && offerBatch[0].ID == lastBatchFirstID {
			repeatCount++
			if repeatCount >= 2 {
				addLog(fmt.Sprintf("⚠️ Rovnaký batch sa opakuje %dx — zastavujem loop", repeatCount+1))
				// Force mark all as unmatched
				for _, o := range offerBatch {
					h.db.Pool.Exec(ctx, `UPDATE offers SET match_type = 'ai_unmatched' WHERE id = $1`, o.ID)
				}
				break
			}
		} else {
			repeatCount = 0
		}
		if len(offerBatch) > 0 { lastBatchFirstID = offerBatch[0].ID }

		addLog(fmt.Sprintf("📦 Batch %d ponúk (celkom: %d)", len(offerBatch), totalProcessed))
		existingCategories := h.getExistingCategoryTree(ctx)
		if totalProcessed <= 20 {
			treeStr := buildCategoryTreeContext(existingCategories)
			addLog(fmt.Sprintf("🌳 Strom: %d kategórií, kontext: %d znakov", len(existingCategories), len(treeStr)))
		}

		// ============================================================
		// TWO-PASS: 1) Feed/cache match   2) Batch AI for remainder
		// ============================================================
		type pendingOffer struct {
			Offer    offerItem
			FeedParts []string
			FeedCatID string // partial feed match (fallback)
		}
		var needsAI []pendingOffer

		// PASS 1: Feed/cache match — instant, no AI cost
		for i, offer := range offerBatch {
			totalProcessed++
			feedParts := normalizeFeedParts(offer.Category)
			var categoryID string
			var method string

			if offer.Category != "" && !isUltra && !isCreative {
				addLog(fmt.Sprintf("📁 Feed: '%s' → '%s'", truncateTitle(offer.Title, 30), offer.Category))
				cacheKey := offer.Category
				
				// 1. Memory cache (fastest) — ALE validuj leaf!
				if cachedID, ok := feedCategoryCache[cacheKey]; ok {
					cacheValid := true
					if (isSmart || isSmartCreate) && len(feedParts) >= 2 {
						// LEAF VALIDÁCIA: Cached kategória MUSÍ matchovať posledný feedPart
						feedLeaf := strings.ToLower(strings.TrimSpace(feedParts[len(feedParts)-1]))
						var cachedName string
						h.db.Pool.QueryRow(ctx, `SELECT LOWER(name) FROM categories WHERE id = $1`, cachedID).Scan(&cachedName)
						cachedName = strings.TrimSpace(cachedName)
						
						// Strict leaf check: musia byť podobné, nie rodič→dieťa
						leafOK := cachedName == feedLeaf ||
							(strings.Contains(cachedName, feedLeaf) && len(cachedName) <= len(feedLeaf)*2) ||
							(strings.Contains(feedLeaf, cachedName) && len(feedLeaf) <= len(cachedName)*2)
						
						if !leafOK {
							cacheValid = false
							delete(feedCategoryCache, cacheKey)
							h.db.Pool.Exec(ctx, `DELETE FROM feed_category_cache WHERE feed_category = $1`, cacheKey)
							addLog(fmt.Sprintf("   ⚠️ Cache leaf mismatch: '%s' ≠ feed leaf '%s' → AI", cachedName, feedLeaf))
						}
					}
					if cacheValid {
						categoryID = cachedID
						method = "💾 Cache"
					}
				}
				
				// 2. Feed tree match (for fast mode only)
				if categoryID == "" && !isPrecise && !isSmart && !isSmartCreate {
					catID := h.matchFeedPathToTree(ctx, feedParts, existingCategories, shopID)
					if catID != "" {
						categoryID = catID
						method = "📁 Feed match"
						feedCategoryCache[cacheKey] = categoryID
						h.saveFeedCategoryToDB(ctx, cacheKey, categoryID)
					}
				}
				
				// 3. Smart/Smart+ mode: feed match, verify quality
				if categoryID == "" && (isSmart || isSmartCreate) {
					catID := h.matchFeedPathToTree(ctx, feedParts, existingCategories, shopID)
					if catID != "" {
						// LEAF VALIDÁCIA: matchnutá kategória musí zodpovedať feed leaf
						feedLeaf := strings.ToLower(strings.TrimSpace(feedParts[len(feedParts)-1]))
						var matchedName string
						h.db.Pool.QueryRow(ctx, `SELECT LOWER(name) FROM categories WHERE id = $1`, catID).Scan(&matchedName)
						matchedName = strings.TrimSpace(matchedName)
						
						leafOK := matchedName == feedLeaf ||
							(strings.Contains(matchedName, feedLeaf) && len(matchedName) <= len(feedLeaf)*2) ||
							(strings.Contains(feedLeaf, matchedName) && len(feedLeaf) <= len(matchedName)*2)
						
						if leafOK {
							categoryID = catID
							method = "📁 Feed match"
							feedCategoryCache[cacheKey] = categoryID
							h.saveFeedCategoryToDB(ctx, cacheKey, categoryID)
						} else {
							// Feed match je plytký (napr. "Hry" namiesto "Spoločenské hry") → AI
							needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts, FeedCatID: catID})
							addLog(fmt.Sprintf("   → Feed match '%s' ≠ leaf '%s', posielam do AI", matchedName, feedLeaf))
							continue
						}
					} else {
						// Žiadny feed match → AI
						needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts, FeedCatID: catID})
						continue
					}
				}
				
				// 4. Precise/Ultra: always use AI
				if categoryID == "" && (isPrecise) {
					catID := h.matchFeedPathToTree(ctx, feedParts, existingCategories, shopID)
					needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts, FeedCatID: catID})
					continue
				}
				
				// 5. Fast mode: no feed match → try AI
				if categoryID == "" {
					needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts})
					continue
				}
			} else if isCreative {
				// Kreatívna: ak máme uložený AI návrh → použi ho, inak AI fresh
				if offer.AISuggestedCategory != "" {
					suggestedParts := strings.Split(offer.AISuggestedCategory, " > ")
					categoryID = h.findOrCreateCategoryPath(ctx, suggestedParts, &existingCategories, shopID)
					if categoryID != "" {
						method = "🆕 Kreatívna (z AI návrhu)"
					}
				}
				if categoryID == "" {
					needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts})
					continue
				}
			} else if isUltra {
				// Ultra: always AI
				needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts})
				continue
			} else if offer.Category == "" && (isPrecise || isSmart || isSmartCreate) {
				// No feed category but AI mode — defer to AI
				needsAI = append(needsAI, pendingOffer{Offer: offerBatch[i], FeedParts: feedParts})
				continue
			} else if offer.Category == "" {
				// No feed category, fast mode — mark unmatched for Creative
				totalErrors++
				h.db.Pool.Exec(ctx, `UPDATE offers SET match_type = 'ai_unmatched' WHERE id = $1`, offer.ID)
				addLog(fmt.Sprintf("⏳ Nezaradené (bez feed): %s", truncateTitle(offer.Title, 50)))
				continue
			}

			if categoryID == "" {
				totalErrors++
				h.db.Pool.Exec(ctx, `UPDATE offers SET match_type = 'ai_unmatched' WHERE id = $1`, offer.ID)
				addLog(fmt.Sprintf("⏳ Nezaradené (feed miss): %s [feed: %s]", truncateTitle(offer.Title, 40), truncateTitle(offer.Category, 40)))
				continue
			}
			// Create product from matched offer
			h.createProductFromOffer(ctx, offer, categoryID, method, shopID, &totalCategorized, &totalNewProducts, &totalErrors, addLog, addError)
			if method != "💾 Cache" {
				path := h.buildCategoryPath(ctx, categoryID)
				addLog(fmt.Sprintf("%s: \"%s\" → %s", method, truncateTitle(offer.Title, 40), path))
			}
		}

		// PASS 2: Batch AI — send 5 products per API call
		useBranchFilter := isSmart || isSmartCreate // Both smart modes use branch-filtered tree
		aiBatchSize := 5
		if isSmart || isSmartCreate { aiBatchSize = 12 } // Smart: branch filter = malý kontext, zmestí sa viac
		for batchStart := 0; batchStart < len(needsAI); batchStart += aiBatchSize {
			// Check if still running
			var status string
			h.db.Pool.QueryRow(ctx, `SELECT status FROM ai_categorization_jobs WHERE id = $1`, jobID).Scan(&status)
			if status != "running" { addLog("⏹ Zastavená"); break }

			batchEnd := batchStart + aiBatchSize
			if batchEnd > len(needsAI) { batchEnd = len(needsAI) }
			aiBatch := needsAI[batchStart:batchEnd]

			var batchProducts []batchProduct
			for i, p := range aiBatch {
				desc := ""
				if useDescriptions { desc = p.Offer.Description }
				batchProducts = append(batchProducts, batchProduct{
					Index: i, Title: p.Offer.Title, Description: desc, FeedCategory: p.Offer.Category, FeedParts: p.FeedParts,
				})
			}

			addLog(fmt.Sprintf("🤖 AI batch: %d produktov%s...", len(batchProducts), func() string { if useBranchFilter { return " (branch-filtered)" }; return "" }()))
			canCreate := isSmartCreate || isCreative
			aiResults := h.aiCategorizeBatchV3Smart(provider, apiKey, model, batchProducts, existingCategories, useBranchFilter, canCreate)

			for _, aiRes := range aiResults {
				idx := aiRes.Index
				if idx >= len(aiBatch) { continue }
				pending := aiBatch[idx]
				offer := pending.Offer
				var categoryID string
				var method string

				if aiRes.Error != nil {
					addError(fmt.Sprintf("❌ AI error: '%s': %v", truncateTitle(offer.Title, 40), aiRes.Error))
				} else if aiRes.Result != nil && len(aiRes.Result.CategoryPath) > 0 {
					addLog(fmt.Sprintf("   → AI vrátila: %v", aiRes.Result.CategoryPath))
					
					if isCreative {
						categoryID = h.findOrCreateCategoryPath(ctx, aiRes.Result.CategoryPath, &existingCategories, shopID)
						if categoryID != "" { method = "🆕 AI Kreatívna" }
					} else if isSmartCreate {
						// Smart+: semi-creative — vytvára podkategórie, ale root MUSÍ existovať
						categoryID = h.findOrCreateSmartPath(ctx, aiRes.Result.CategoryPath, &existingCategories, shopID)
						if categoryID != "" { method = "💡+ Smart+ AI" }
					} else {
						// Smart/Presná/Ultra: len existujúce kategórie
						categoryID = h.findExistingCategoryOnly(ctx, aiRes.Result.CategoryPath)
						if categoryID != "" {
							method = "🤖 AI"
							if isSmart { method = "💡 Smart AI" }
							if isUltra { method = "🔬 AI Ultra" }
						}
					}
					
					// POST-AI LEAF VALIDÁCIA (Smart mód): AI nesmie vrátiť plytký match
					// Feed: "Hrácky | Hry | Spoločenské hry" → leaf "Spoločenské hry"
					// AI vrátila: ["Hračky a hry", "Hry"] → leaf "Hry" ≠ "Spoločenské hry" → ODMIETNUŤ
					if categoryID != "" && isSmart && len(pending.FeedParts) >= 2 {
						feedLeaf := strings.ToLower(strings.TrimSpace(pending.FeedParts[len(pending.FeedParts)-1]))
						aiLeaf := strings.ToLower(strings.TrimSpace(aiRes.Result.CategoryPath[len(aiRes.Result.CategoryPath)-1]))
						
						leafOK := aiLeaf == feedLeaf ||
							(strings.Contains(aiLeaf, feedLeaf) && len(aiLeaf) <= len(feedLeaf)*2) ||
							(strings.Contains(feedLeaf, aiLeaf) && len(feedLeaf) <= len(aiLeaf)*2)
						
						if !leafOK {
							addLog(fmt.Sprintf("   ⚠️ AI leaf '%s' ≠ feed leaf '%s' → plytký match, nezaradené", aiLeaf, feedLeaf))
							categoryID = "" // Odmietnuť — nech Kreatívna vytvorí správnu podkategóriu
						}
					}
				}

				// NENAŠLO SA → označ ako ai_unmatched + ulož AI-navrhnutú cestu
				if categoryID == "" {
					totalErrors++
					suggestedPath := ""
					if aiRes.Result != nil && len(aiRes.Result.CategoryPath) > 0 {
						suggestedPath = strings.Join(aiRes.Result.CategoryPath, " > ")
					}
					h.db.Pool.Exec(ctx, `UPDATE offers SET match_type = 'ai_unmatched', ai_suggested_category = $2 WHERE id = $1`, offer.ID, suggestedPath)
					feedInfo := ""
					if offer.Category != "" { feedInfo = fmt.Sprintf(" [feed: %s]", truncateTitle(offer.Category, 40)) }
					aiInfo := ""
					if suggestedPath != "" { aiInfo = fmt.Sprintf(" [AI navrhla: %s]", truncateTitle(suggestedPath, 50)) }
					addLog(fmt.Sprintf("⏳ Nezaradené: %s%s%s", truncateTitle(offer.Title, 40), feedInfo, aiInfo))
					continue
				}

				// Cache the result (memory + DB)
				if offer.Category != "" {
					feedCategoryCache[offer.Category] = categoryID
					h.saveFeedCategoryToDB(ctx, offer.Category, categoryID)
				}

				h.createProductFromOffer(ctx, offer, categoryID, method, shopID, &totalCategorized, &totalNewProducts, &totalErrors, addLog, addError)
				path := h.buildCategoryPath(ctx, categoryID)
				addLog(fmt.Sprintf("%s: \"%s\" → %s", method, truncateTitle(offer.Title, 40), path))
			}
			time.Sleep(200 * time.Millisecond) // Small delay between batches
		}

		h.updateJobStats(ctx, jobID, totalProcessed, totalCategorized, totalNewProducts, totalNewCats, totalErrors)
	}

	summaryExtra := ""
	if isPrecise { summaryExtra = fmt.Sprintf(", AI potvrdených: %d, AI opravených: %d, Cache hitov: %d", totalAIVerified, totalAICorrected, len(feedCategoryCache)) }
	addLog(fmt.Sprintf("🏁 Hotovo! Spracovaných: %d, Kategorizovaných: %d, Nových produktov: %d, Nových kategórií: %d, Chýb: %d%s", totalProcessed, totalCategorized, totalNewProducts, totalNewCats, totalErrors, summaryExtra))
	h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET status = 'completed', finished_at = NOW() WHERE id = $1`, jobID)
	h.updateCategoryProductCounts(ctx)

	// Sync product prices from offers (fix 0€ products)
	h.db.Pool.Exec(ctx, `
		UPDATE products p SET 
			price_min = COALESCE((SELECT MIN(o.price) FROM offers o WHERE o.product_id = p.id AND o.price > 0), p.price_min),
			price_max = COALESCE((SELECT MAX(o.price) FROM offers o WHERE o.product_id = p.id AND o.price > 0), p.price_max),
			offer_count = (SELECT COUNT(*) FROM offers o WHERE o.product_id = p.id)
		WHERE p.id IN (SELECT DISTINCT product_id FROM offers WHERE product_id IS NOT NULL)
	`)
	addLog("💰 Ceny produktov synchronizované z ponúk")
}

// ============================================================
// AI VERIFY — Overenie existujúceho zaradenia (pre presný režim)
// ============================================================

type AIVerifyResult struct {
	IsCorrect  bool     `json:"is_correct"`
	BetterPath []string `json:"better_path"`
	Reasoning  string   `json:"reasoning"`
}

func (h *Handler) aiVerifyCategory(provider, apiKey, model, productTitle, feedCategory, currentPath string, categories []map[string]interface{}) (*AIVerifyResult, error) {
	catTreeStr := buildCategoryTreeContext(categories)

	prompt := fmt.Sprintf(`Si audítor kategorizácie pre slovenský porovnávač cien MegaPrice.sk.

PRODUKT: %s
FEED KATEGÓRIA: %s
AKTUÁLNA KATEGÓRIA: %s

STROM:
%s

ÚLOHA: Je aktuálna kategória SPRÁVNA pre tento produkt?

Ak ÁNO → {"is_correct": true, "better_path": [], "reasoning": "Prečo je správna"}
Ak NIE → {"is_correct": false, "better_path": ["Root","Sub","Lepšia"], "reasoning": "Prečo je lepšia"}

Len vtedy oprav, keď je JASNE zlá alebo veľmi nepresná. Pri pochybnostiach nechaj pôvodnú.
Všetko v slovenčine. JSON (ŽIADNY iný text):`, productTitle, feedCategory, currentPath, catTreeStr)

	var responseText string
	var err error
	if provider == "openai" {
		responseText, err = callOpenAIAPIV3(prompt, apiKey, model)
	} else {
		responseText, err = callClaudeAPIV3(prompt, apiKey, model)
	}
	if err != nil { return nil, err }

	responseText = strings.TrimSpace(responseText)
	responseText = strings.TrimPrefix(responseText, "```json")
	responseText = strings.TrimPrefix(responseText, "```")
	responseText = strings.TrimSuffix(responseText, "```")
	responseText = strings.TrimSpace(responseText)
	start := strings.Index(responseText, "{")
	end := strings.LastIndex(responseText, "}")
	if start >= 0 && end > start { responseText = responseText[start : end+1] }

	var result AIVerifyResult
	if err := json.Unmarshal([]byte(responseText), &result); err != nil {
		return &AIVerifyResult{IsCorrect: true}, nil // Pri parse errore nechaj pôvodnú
	}
	return &result, nil
}

// ============================================================
// FUZZY STRING MATCHING PRE KATEGÓRIE
// ============================================================

// Odstráni diakritiku: á→a, č→c, ž→z, atď.
func removeDiacritics(s string) string {
	replacer := strings.NewReplacer(
		"á", "a", "Á", "A", "ä", "a", "Ä", "A",
		"č", "c", "Č", "C", "ď", "d", "Ď", "D",
		"é", "e", "É", "E", "ě", "e", "Ě", "E",
		"í", "i", "Í", "I", "ľ", "l", "Ľ", "L",
		"ň", "n", "Ň", "N", "ó", "o", "Ó", "O",
		"ô", "o", "Ô", "O", "ö", "o", "Ö", "O",
		"ř", "r", "Ř", "R", "š", "s", "Š", "S",
		"ť", "t", "Ť", "T", "ú", "u", "Ú", "U",
		"ů", "u", "Ů", "U", "ü", "u", "Ü", "U",
		"ý", "y", "Ý", "Y", "ž", "z", "Ž", "Z",
	)
	return replacer.Replace(s)
}

// Levenshtein distance
func levenshtein(a, b string) int {
	if len(a) == 0 { return len(b) }
	if len(b) == 0 { return len(a) }
	prev := make([]int, len(b)+1)
	curr := make([]int, len(b)+1)
	for j := range prev { prev[j] = j }
	for i := 1; i <= len(a); i++ {
		curr[0] = i
		for j := 1; j <= len(b); j++ {
			cost := 1
			if a[i-1] == b[j-1] { cost = 0 }
			curr[j] = min(curr[j-1]+1, min(prev[j]+1, prev[j-1]+cost))
		}
		prev, curr = curr, prev
	}
	return prev[len(b)]
}

// Similarity 0.0 – 1.0. Najprv skúsi bez diakritiky, potom Levenshtein.
func categorySimilarity(a, b string) float64 {
	a = strings.ToLower(strings.TrimSpace(a))
	b = strings.ToLower(strings.TrimSpace(b))
	if a == b { return 1.0 }
	// Bez diakritiky — "Slúchadlá" vs "Sluchadla" = match
	aNorm := strings.ToLower(removeDiacritics(a))
	bNorm := strings.ToLower(removeDiacritics(b))
	if aNorm == bNorm { return 0.95 }
	// Levenshtein
	maxLen := len(aNorm)
	if len(bNorm) > maxLen { maxLen = len(bNorm) }
	if maxLen == 0 { return 1.0 }
	dist := levenshtein(aNorm, bNorm)
	return 1.0 - float64(dist)/float64(maxLen)
}

// Fuzzy match: nájdi najlepšiu kategóriu na danej úrovni (parent)
// Vráti catID ak similarity ≥ threshold (0.80), inak ""
func (h *Handler) fuzzyFindCategory(ctx context.Context, name string, parentID *string, categories []map[string]interface{}) string {
	bestID := ""
	bestSim := 0.0
	threshold := 0.80

	for _, cat := range categories {
		catName := cat["name"].(string)
		catParentID, _ := cat["parent_id"].(*string)
		sameParent := (parentID == nil && catParentID == nil) || (parentID != nil && catParentID != nil && *parentID == *catParentID)
		if !sameParent { continue }
		sim := categorySimilarity(name, catName)
		if sim > bestSim {
			bestSim = sim
			bestID = cat["id"].(string)
		}
	}

	if bestSim >= threshold { return bestID }
	return ""
}

// DB-level fuzzy: pre findOrCreateCategoryPath
func (h *Handler) fuzzyFindCategoryDB(ctx context.Context, name string, parentID *string) string {
	var query string
	var args []interface{}
	if parentID == nil {
		query = `SELECT id, name FROM categories WHERE parent_id IS NULL`
		args = nil
	} else {
		query = `SELECT id, name FROM categories WHERE parent_id = $1`
		args = []interface{}{*parentID}
	}
	rows, err := h.db.Pool.Query(ctx, query, args...)
	if err != nil { return "" }
	defer rows.Close()

	bestID := ""
	bestSim := 0.0
	for rows.Next() {
		var catID, catName string
		rows.Scan(&catID, &catName)
		sim := categorySimilarity(name, catName)
		if sim > bestSim { bestSim = sim; bestID = catID }
	}
	if bestSim >= 0.80 { return bestID }
	return ""
}

// fuzzyFindCategoryGlobal — hľadá vo VŠETKÝCH kategóriách (nie len root/children)
func (h *Handler) fuzzyFindCategoryGlobal(ctx context.Context, name string) string {
	rows, err := h.db.Pool.Query(ctx, `SELECT id, name FROM categories`)
	if err != nil { return "" }
	defer rows.Close()

	bestID := ""
	bestSim := 0.0
	for rows.Next() {
		var catID, catName string
		rows.Scan(&catID, &catName)
		sim := categorySimilarity(name, catName)
		if sim > bestSim { bestSim = sim; bestID = catID }
	}
	if bestSim >= 0.70 { return bestID } // 70% pre globálny — tolerantnejšie
	return ""
}

// ============================================================
// FEED PATH → TREE MATCHING
// ============================================================

func (h *Handler) findRootCategory(rootName string, categories []map[string]interface{}) string {
	// 1. Presný match
	for _, cat := range categories {
		parentID, _ := cat["parent_id"].(*string)
		if parentID != nil && *parentID != "" { continue }
		if strings.EqualFold(cat["name"].(string), rootName) { return cat["id"].(string) }
	}
	// 2. Fuzzy match pre root (≥80%)
	bestID := ""
	bestSim := 0.0
	for _, cat := range categories {
		parentID, _ := cat["parent_id"].(*string)
		if parentID != nil && *parentID != "" { continue }
		sim := categorySimilarity(rootName, cat["name"].(string))
		if sim > bestSim { bestSim = sim; bestID = cat["id"].(string) }
	}
	if bestSim >= 0.80 { return bestID }
	return ""
}

func (h *Handler) matchFeedPathToTree(ctx context.Context, feedParts []string, categories []map[string]interface{}, shopID string) string {
	if len(feedParts) == 0 { return "" }
	var currentParentID *string = nil
	lastMatchedID := ""
	lastMatchedLevel := -1

	for level, feedName := range feedParts {
		found := false
		// 1. Presný match (slug alebo name) pod rodičom
		for _, cat := range categories {
			catName := cat["name"].(string)
			catParentID, _ := cat["parent_id"].(*string)
			sameParent := (currentParentID == nil && catParentID == nil) || (currentParentID != nil && catParentID != nil && *currentParentID == *catParentID)
			if sameParent && strings.EqualFold(catName, feedName) {
				catID := cat["id"].(string)
				currentParentID = &catID
				lastMatchedID = catID
				lastMatchedLevel = level
				found = true
				break
			}
		}
		// 2. Fuzzy match (≥85% podobnosť) — len pod rodičom, BEZPEČNÉ
		if !found {
			fuzzyID := h.fuzzyFindCategory(ctx, feedName, currentParentID, categories)
			if fuzzyID != "" {
				currentParentID = &fuzzyID
				lastMatchedID = fuzzyID
				lastMatchedLevel = level
				found = true
			}
		}
		if !found { break }
	}

	// PRAVIDLO: LEAF MUSÍ EXISTOVAŤ
	// Feed "Hrácky | Hádanky | 3D puzzle" → musíme matchnúť aj "3D puzzle"
	// Ak matchneme len "Hádanky" (level 1 z 2) → vrátime "" (nech kreatívna vytvorí)
	if lastMatchedLevel < len(feedParts)-1 {
		return "" // Partial match = nezaradiť
	}

	return lastMatchedID
}

// ============================================================
// POST-AI VALIDÁCIA V3
// ============================================================

func slicesEqual(a, b []string) bool {
	if len(a) != len(b) { return false }
	for i := range a { if a[i] != b[i] { return false } }
	return true
}

func (h *Handler) getCategoryName(ctx context.Context, catID string) string {
	var name string
	h.db.Pool.QueryRow(ctx, `SELECT name FROM categories WHERE id = $1`, catID).Scan(&name)
	return name
}

func validateCategoryPathV3(aiPath []string, feedParts []string) []string {
	if len(aiPath) == 0 && len(feedParts) > 0 { return feedParts }
	if len(aiPath) == 0 { return aiPath }
	if len(feedParts) == 0 { return aiPath }

	feedRootDomain := getDomainForName(feedParts[0])
	aiRootDomain := getDomainForName(aiPath[0])

	// PRAVIDLO 1: Root domény MUSIA sedieť
	if feedRootDomain != "" && aiRootDomain != "" && feedRootDomain != aiRootDomain {
		return feedParts
	}

	// PRAVIDLO 2: Cross-domain na 2. úrovni (Elektronika > Hračky)
	if len(aiPath) >= 2 {
		secondDomain := getDomainForName(aiPath[1])
		if aiRootDomain != "" && secondDomain != "" && aiRootDomain != secondDomain {
			return feedParts
		}
	}

	// PRAVIDLO 3: AI ignorovala feed root
	if len(feedParts) > 0 && len(aiPath) > 0 {
		if feedRootDomain != "" && (aiRootDomain == "" || aiRootDomain != feedRootDomain) && !strings.EqualFold(feedParts[0], aiPath[0]) {
			return feedParts
		}
	}

	// PRAVIDLO 4: Feed leaf musí byť v výsledku
	if len(feedParts) > 1 { aiPath = ensureFeedLeafInPath(aiPath, feedParts) }
	return aiPath
}

func ensureFeedLeafInPath(aiPath []string, feedParts []string) []string {
	if len(feedParts) <= 1 || len(aiPath) == 0 { return aiPath }
	feedLeaf := strings.TrimSpace(feedParts[len(feedParts)-1])
	if feedLeaf == "" { return aiPath }
	for _, ap := range aiPath {
		if strings.EqualFold(strings.TrimSpace(ap), feedLeaf) { return aiPath }
	}
	aiLastInFeed := -1
	for i, fp := range feedParts {
		for _, ap := range aiPath {
			if strings.EqualFold(strings.TrimSpace(ap), strings.TrimSpace(fp)) {
				if i > aiLastInFeed { aiLastInFeed = i }
			}
		}
	}
	if aiLastInFeed >= 0 && aiLastInFeed < len(feedParts)-1 {
		for j := aiLastInFeed + 1; j < len(feedParts); j++ {
			part := strings.TrimSpace(feedParts[j])
			if part != "" { aiPath = append(aiPath, part) }
		}
	} else if aiLastInFeed == -1 {
		aiPath = append(aiPath, feedLeaf)
	}
	return aiPath
}

// ============================================================
// AI V3 — VYLEPŠENÝ PROMPT + SKUTOČNÉ MODELY
// ============================================================

type AICategorizeResult struct {
	CategoryPath       []string
	Brand              string
	CreatedNewCategory bool
}

func (h *Handler) getActiveModel(ctx context.Context, provider string) string {
	if provider == "openai" {
		model := h.getAISetting(ctx, "ai_model_openai")
		if model == "" { model = "gpt-4o" }
		return model
	}
	model := h.getAISetting(ctx, "ai_model_anthropic")
	if model == "" { model = "claude-sonnet-4-20250514" }
	return model
}

func (h *Handler) aiCategorizeV3(provider, apiKey, model, productTitle, rawFeedCategory string, feedParts []string, description string, categories []map[string]interface{}) (*AICategorizeResult, error) {
	catTreeStr := buildCategoryTreeContext(categories)
	var rootCats []string
	for _, cat := range categories {
		parentID, _ := cat["parent_id"].(*string)
		if parentID == nil || *parentID == "" { rootCats = append(rootCats, cat["name"].(string)) }
	}
	rootList := strings.Join(rootCats, ", ")

	var prompt string
	if len(feedParts) > 0 && rawFeedCategory != "" {
		feedPathStr := strings.Join(feedParts, " > ")
		prompt = fmt.Sprintf(`Si profesionálny kategorizačný systém pre slovenský CPC porovnávač cien MegaPrice.sk.

PRODUKT: %s
FEED KATEGÓRIA (ORIGINÁL): %s
FEED KATEGÓRIA (NORMALIZOVANÁ): %s

EXISTUJÚCE ROOT KATEGÓRIE: %s

AKTUÁLNY STROM KATEGÓRIÍ:
%s

═══════════════════════════════════════
TVOJA ÚLOHA (postupuj presne v tomto poradí):
═══════════════════════════════════════

PRIORITA 1 — POUŽI EXISTUJÚCU KATEGÓRIU
Prechádzaj celý strom a hľadaj, kam produkt logicky patrí.
Ak nájdeš vhodnú existujúcu koncovú kategóriu → použi ju!
Príklad: Feed "Computer > Muis" a v strome je "IT > Periférie > Myši" → použi ["IT", "Periférie", "Myši"]

PRIORITA 2 — VYTVOR PODKATEGÓRIU POD EXISTUJÚCIM RODIČOM
Ak existuje vhodný rodič ale chýba špecifická podkategória → pridaj ju.
Príklad: Feed "Geluid > Gaming headset" a v strome je "Elektronika > Slúchadlá" → použi ["Elektronika", "Slúchadlá", "Herné slúchadlá"]
Príklad: Feed "Kleding > Sokken" a v strome je "Oblečenie" → použi ["Oblečenie", "Ponožky"]

PRIORITA 3 — VYTVOR NOVÝ LOGICKÝ STROM
Len ak žiadna existujúca kategória nevyhovuje, vytvor nový strom.
Vždy zachovaj logickú hierarchiu a max 4 úrovne.
Príklad: Feed "Fietsen > Helmen" a nič podobné neexistuje → vytvor ["Šport", "Cyklistika", "Prilby"]

═══════════════════════════════════════
STRIKTNÉ PRAVIDLÁ:
═══════════════════════════════════════

1. VŠETKO V SLOVENČINE! Prekladaj názvy kategórií do slovenčiny.
   "Computers" → "Počítače", "Geluid" → "Zvuk/Audio", "Speelgoed" → "Hračky"
   "Koptelefoon" → "Slúchadlá", "Muis" → "Myši", "Kleding" → "Oblečenie"
   Výnimka: technické názvy (USB, HDMI, Bluetooth, WiFi) ponechaj.

2. REŠPEKTUJ FEED — feed kategória je dôverný zdroj informácií o produkte.
   Zachovaj špecifickosť koncovej kategórie!
   Feed: "Zvuk > Slúchadlá > S mikrofónom" → koncová MUSÍ byť "Slúchadlá s mikrofónom"

3. NIKDY NEKRÍŽI DOMÉNY!
   Audio/Zvuk → Elektronika (NIE Hudobné nástroje)
   Gaming headset → Elektronika > Slúchadlá (NIE Hry)
   Hudobné nástroje = LEN gitara, klavír, bicie atď.

4. KONTEXTOVÁ INTELIGENCIA:
   "Příslušenství" v IT kontexte = Periférie (myši, klávesnice)
   "Příslušenství" v auto kontexte = Autodoplnky
   "Muis matten" v IT = Podložky pod myš

5. SPRÁVNE ROOT MAPOVANIE:
   Zvuk/Audio/Geluid/Sound → Elektronika
   Computer/Počítač/PC → IT alebo Počítače
   Speelgoed/Toys/Hračky → Hry a hračky
   Huis/Home/Dom → Dom a záhrada
   Kleding/Clothing → Oblečenie
   Sport/Fitness → Šport

6. Nastav "is_new": false ak použiváš existujúcu cestu, true ak vytváraš novú.

JSON (ŽIADNY iný text, žiadne markdown):
{"category_path": ["Root", "Sub", "Koncová"], "brand": "Značka alebo prázdny string", "is_new": false}`, productTitle, rawFeedCategory, feedPathStr, rootList, catTreeStr)
	} else if description != "" {
		shortDesc := description
		if len(shortDesc) > 500 { shortDesc = shortDesc[:500] }
		prompt = fmt.Sprintf(`Si profesionálny kategorizačný systém pre slovenský CPC porovnávač cien MegaPrice.sk.

PRODUKT: %s
POPIS: %s

EXISTUJÚCE ROOT KATEGÓRIE: %s

STROM:
%s

ÚLOHA: Zaraď produkt do správnej kategórie. Vždy najprv skús nájsť existujúcu kategóriu v strome.
Ak neexistuje vhodná → vytvor novú podkategóriu pod existujúcim rodičom.
Ak ani rodič neexistuje → vytvor nový logický strom (max 4 úrovne).
Všetko v SLOVENČINE. Nikdy nekríži domény. Použi názov a popis produktu na správne zaradenie.

JSON (ŽIADNY iný text):
{"category_path": ["Root","Sub","Koncová"], "brand": "Značka", "is_new": false}`, productTitle, shortDesc, rootList, catTreeStr)
	} else {
		prompt = fmt.Sprintf(`Si profesionálny kategorizačný systém pre slovenský CPC porovnávač cien MegaPrice.sk.

PRODUKT: %s

EXISTUJÚCE ROOT KATEGÓRIE: %s

STROM:
%s

ÚLOHA: Zaraď produkt do správnej kategórie. Vždy najprv skús nájsť existujúcu kategóriu v strome.
Ak neexistuje vhodná → vytvor novú podkategóriu pod existujúcim rodičom.
Ak ani rodič neexistuje → vytvor nový logický strom (max 4 úrovne).
Všetko v SLOVENČINE. Nikdy nekríži domény.

JSON (ŽIADNY iný text):
{"category_path": ["Root","Sub","Koncová"], "brand": "Značka", "is_new": false}`, productTitle, rootList, catTreeStr)
	}

	var responseText string
	var err error
	if provider == "openai" {
		responseText, err = callOpenAIAPIV3(prompt, apiKey, model)
	} else {
		responseText, err = callClaudeAPIV3(prompt, apiKey, model)
	}
	if err != nil { return nil, err }
	return parseAIResponse(responseText)
}

// Backward compat
func (h *Handler) aiCategorizeV2(provider, apiKey, productTitle, feedCategory, description string, categories []map[string]interface{}) (*AICategorizeResult, error) {
	ctx := context.Background()
	model := h.getActiveModel(ctx, provider)
	feedParts := normalizeFeedParts(feedCategory)
	return h.aiCategorizeV3(provider, apiKey, model, productTitle, feedCategory, feedParts, description, categories)
}
func (h *Handler) aiCategorizeWithContext(provider, apiKey, productTitle, feedCategory, description string, categories []map[string]interface{}) (*AICategorizeResult, error) {
	return h.aiCategorizeV2(provider, apiKey, productTitle, feedCategory, description, categories)
}
func (h *Handler) aiCategorizeProduct(provider, apiKey, productTitle, categoryContext string) (*AICategorizeResult, error) {
	categories := h.getExistingCategoryTree(context.Background())
	return h.aiCategorizeV2(provider, apiKey, productTitle, "", "", categories)
}
func (h *Handler) aiCategorizeProductFull(provider, apiKey, productTitle, feedCategory, description, categoryContext string) (*AICategorizeResult, error) {
	categories := h.getExistingCategoryTree(context.Background())
	return h.aiCategorizeV2(provider, apiKey, productTitle, feedCategory, description, categories)
}

// ============================================================
// API CALLS — SKUTOČNE POUŽÍVAJÚ MODEL!
// ============================================================

func callOpenAIAPIV3(prompt, apiKey, model string) (string, error) {
	if apiKey == "" { return "", fmt.Errorf("OpenAI API key is required") }
	if model == "" { model = "gpt-4o" }
	reqBody := map[string]interface{}{
		"model": model, "max_tokens": 500, "temperature": 0.05,
		"messages": []map[string]string{
			{"role": "system", "content": "Si presný kategorizačný systém pre slovenský e-shop. Odpovedáš LEN validným JSON bez markdown. VŽDY najprv hľadaj existujúcu kategóriu v strome. Všetky názvy kategórií MUSIA byť v slovenčine. Nikdy nekríži domény (audio≠hudobné nástroje). Produkt môže mať názov v akomkoľvek jazyku (holandčina, angličtina, nemčina) — preložíš do slovenčiny."},
			{"role": "user", "content": prompt},
		},
	}
	jsonBody, _ := json.Marshal(reqBody)

	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 { time.Sleep(time.Duration(attempt*2) * time.Second) }
		req, _ := http.NewRequest("POST", "https://api.openai.com/v1/chat/completions", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Authorization", "Bearer "+apiKey)
		client := &http.Client{Timeout: 60 * time.Second}
		resp, err := client.Do(req)
		if err != nil { lastErr = err; continue }
		defer resp.Body.Close()
		if resp.StatusCode == 429 || resp.StatusCode >= 500 {
			body, _ := io.ReadAll(resp.Body)
			lastErr = fmt.Errorf("OpenAI HTTP %d: %s", resp.StatusCode, string(body[:min(200, len(body))]))
			continue
		}
		var result struct {
			Choices []struct { Message struct { Content string `json:"content"` } `json:"message"` } `json:"choices"`
			Error struct { Message string `json:"message"` } `json:"error"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&result); err != nil { return "", err }
		if result.Error.Message != "" { return "", fmt.Errorf("OpenAI: %s", result.Error.Message) }
		if len(result.Choices) > 0 { return result.Choices[0].Message.Content, nil }
		return "", fmt.Errorf("no response from OpenAI")
	}
	return "", fmt.Errorf("OpenAI failed after 3 retries: %v", lastErr)
}

func callClaudeAPIV3(prompt, apiKey, model string) (string, error) {
	if apiKey == "" { return "", fmt.Errorf("Claude API key is required") }
	if model == "" { model = "claude-sonnet-4-20250514" }
	reqBody := map[string]interface{}{
		"model": model, "max_tokens": 500, "temperature": 0.05,
		"system": "Si presný kategorizačný systém pre slovenský e-shop. Odpovedáš LEN validným JSON bez markdown. VŽDY najprv hľadaj existujúcu kategóriu v strome. Všetky názvy kategórií MUSIA byť v slovenčine. Nikdy nekríži domény (audio≠hudobné nástroje). Produkt môže mať názov v akomkoľvek jazyku (holandčina, angličtina, nemčina) — preložíš do slovenčiny.",
		"messages": []map[string]interface{}{{"role": "user", "content": prompt}},
	}
	jsonBody, _ := json.Marshal(reqBody)

	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 { time.Sleep(time.Duration(attempt*2) * time.Second) }
		req, _ := http.NewRequest("POST", "https://api.anthropic.com/v1/messages", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("x-api-key", apiKey)
		req.Header.Set("anthropic-version", "2023-06-01")
		client := &http.Client{Timeout: 60 * time.Second}
		resp, err := client.Do(req)
		if err != nil { lastErr = err; continue }
		defer resp.Body.Close()
		if resp.StatusCode == 429 || resp.StatusCode >= 500 {
			body, _ := io.ReadAll(resp.Body)
			lastErr = fmt.Errorf("Claude HTTP %d: %s", resp.StatusCode, string(body[:min(200, len(body))]))
			continue
		}
		var result struct {
			Content []struct { Text string `json:"text"` } `json:"content"`
			Error struct { Message string `json:"message"` } `json:"error"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&result); err != nil { return "", err }
		if result.Error.Message != "" { return "", fmt.Errorf("Claude: %s", result.Error.Message) }
		if len(result.Content) > 0 { return result.Content[0].Text, nil }
		return "", fmt.Errorf("no response from Claude")
	}
	return "", fmt.Errorf("Claude failed after 3 retries: %v", lastErr)
}

// Backward compat wrappers
func callOpenAIAPI(prompt, apiKey string) (string, error) { return callOpenAIAPIV3(prompt, apiKey, "gpt-4o") }
func callClaudeAPI(prompt, apiKey string) (string, error) { return callClaudeAPIV3(prompt, apiKey, "claude-sonnet-4-20250514") }
func callOpenAIAPIWithModel(prompt, apiKey, model string) (string, error) { return callOpenAIAPIV3(prompt, apiKey, model) }
func callClaudeAPIWithModel(prompt, apiKey, model string) (string, error) { return callClaudeAPIV3(prompt, apiKey, model) }

// ============================================================
// HELPER: Create product from offer
// ============================================================

type offerItemForProduct struct {
	ID, Title, Description, EAN, Category string
	Price float64
	ShopID, Image, AISuggestedCategory string
}

func (h *Handler) createProductFromOffer(ctx context.Context, offer offerItemForProduct, categoryID, method, shopID string, totalCategorized, totalNewProducts, totalErrors *int, addLog, addError func(string)) {
	productID := uuid.New().String()
	slug := generateSlug(offer.Title)
	var slugExists bool
	h.db.Pool.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM products WHERE slug = $1)", slug).Scan(&slugExists)
	if slugExists { slug = slug + "-" + productID[:8] }

	_, pErr := h.db.Pool.Exec(ctx, `
		INSERT INTO products (id, title, slug, description, ean, image, category_id, price_min, price_max, published, created_by_shop_id, offer_count, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8, true, $9, 1, NOW(), NOW())
	`, productID, offer.Title, slug, offer.Description, offer.EAN, offer.Image, categoryID, offer.Price, offer.ShopID)
	if pErr != nil {
		*totalErrors++
		addError(fmt.Sprintf("❌ Product insert: %s: %v", truncateTitle(offer.Title, 30), pErr))
		return
	}

	// Match type podľa metódy zaradenia
	matchType := "ai_created"
	switch {
	case strings.Contains(method, "Feed match"):
		matchType = "feed_match"
	case strings.Contains(method, "Cache"):
		matchType = "cache_match"
	case strings.Contains(method, "Smart"), strings.Contains(method, "AI"):
		matchType = "ai_zaradená"
	case strings.Contains(method, "Kreatívna"):
		matchType = "ai_vytvorená_kat"
	case strings.Contains(method, "Ultra"):
		matchType = "ai_zaradená"
	}
	
	h.db.Pool.Exec(ctx, `UPDATE offers SET product_id = $1, match_type = $3 WHERE id = $2`, productID, offer.ID, matchType)
	*totalCategorized++
	*totalNewProducts++
}

// ============================================================
// BATCH AI — 5 produktov v 1 volaní = 5x rýchlejšie
// ============================================================

type batchProduct struct {
	Index        int
	Title        string
	Description  string
	FeedCategory string
	FeedParts    []string
}

type batchResult struct {
	Index  int
	Result *AICategorizeResult
	Error  error
}

func (h *Handler) aiCategorizeBatchV3(provider, apiKey, model string, products []batchProduct, categories []map[string]interface{}) []batchResult {
	return h.aiCategorizeBatchV3Smart(provider, apiKey, model, products, categories, false, false)
}

func (h *Handler) aiCategorizeBatchV3Smart(provider, apiKey, model string, products []batchProduct, categories []map[string]interface{}, useBranchFilter bool, canCreateCategories bool) []batchResult {
	if len(products) == 0 { return nil }
	// Single product — use standard function
	if len(products) == 1 {
		p := products[0]
		result, err := h.aiCategorizeV3(provider, apiKey, model, p.Title, p.FeedCategory, p.FeedParts, "", categories)
		return []batchResult{{Index: p.Index, Result: result, Error: err}}
	}

	// Determine tree context — full or branch-filtered
	var catTreeStr string
	if useBranchFilter {
		// Collect all target roots from feed categories
		rootSet := make(map[string]bool)
		for _, p := range products {
			roots := detectRootFromFeed(p.FeedParts)
			for _, r := range roots { rootSet[r] = true }
		}
		var targetRoots []string
		for r := range rootSet { targetRoots = append(targetRoots, r) }
		catTreeStr = buildBranchTreeContext(categories, targetRoots)
	} else {
		catTreeStr = buildCategoryTreeContext(categories)
	}

	var rootCats []string
	for _, cat := range categories {
		parentID, _ := cat["parent_id"].(*string)
		if parentID == nil || *parentID == "" { rootCats = append(rootCats, cat["name"].(string)) }
	}
	rootList := strings.Join(rootCats, ", ")

	// Build product list for prompt
	var productLines []string
	for i, p := range products {
		feedInfo := ""
		if p.FeedCategory != "" {
			feedInfo = fmt.Sprintf(" [Feed: %s]", p.FeedCategory)
		}
		descInfo := ""
		if p.Description != "" {
			desc := p.Description
			if len(desc) > 150 { desc = desc[:150] + "..." }
			descInfo = fmt.Sprintf(" [Popis: %s]", desc)
		}
		productLines = append(productLines, fmt.Sprintf("%d. PRODUKT: %s%s%s", i+1, p.Title, feedInfo, descInfo))
	}

	// Smart vs Smart+ prompt difference
	var createRule string
	if canCreateCategories {
		createRule = `- Ak presná KONCOVÁ podkategória neexistuje v strome, navrhni logický slovenský názov pod správnym rodičom
- Vždy vráť PLNÚ cestu od root po koncovú kategóriu`
	} else {
		createRule = `- Použi LEN existujúce kategórie z vyššie uvedeného stromu
- KRITICKÉ: Vráť NAJHLBŠIU (koncovú) kategóriu kde produkt patrí — NIE rodiča!
- Ak presná KONCOVÁ kategória pre produkt NEEXISTUJE v strome → vráť PRÁZDNE pole: "category_path": []
- NIKDY nevracaj len root alebo len rodičovskú kategóriu! Radšej vráť [] ako nepresný výsledok
- Príklad: "3D puzzle" ale v strome je len "Hádanky" bez podkategórie "3D puzzle" → vráť []
- Príklad: "Tyčový vysávač" ale v strome nie je "Vysávače" → vráť []
- Príklad: "HDMI kábel" a v strome je "Elektronika > Adaptéry" → vráť ["Elektronika","Adaptéry"] ✅`
	}

	prompt := fmt.Sprintf(`Si profesionálny kategorizačný systém pre slovenský CPC porovnávač cien MegaPrice.sk.

KATEGORIZUJ TIETO %d PRODUKTY do správnych kategórií:
%s

EXISTUJÚCE ROOT KATEGÓRIE: %s

AKTUÁLNY STROM KATEGÓRIÍ (použi PRESNE tieto názvy kde existujú):
%s

PRAVIDLÁ:
- KRITICKÉ: Zaraď produkt podľa jeho NÁZVU a TYPU, nie len podľa feed kategórie!
  Napr. "Autonabíjačka Hama USB" = nabíjačka do auta → Elektronika > Nabíjačky, NIE hry
- Feed kategória je len HINT — vždy over podľa názvu produktu či dáva zmysel
- Použi PRESNÉ názvy kategórií z existujúceho stromu kde existujú
%s
- NIKDY nekríži domény (hračky≠zvieratá, audio≠hudobné nástroje, nabíjačky≠hry)
- NIKDY nevracaj len ROOT kategóriu — vždy musí byť aspoň 2 úrovne, alebo []
- Všetky názvy v SLOVENČINE

Odpovedz LEN validným JSON poľom (ŽIADNY iný text, žiadne markdown):
[
  {"n": 1, "category_path": ["Root","Sub","Koncová"], "brand": "Značka"},
  {"n": 2, "category_path": [], "brand": ""},
  ...
]
Prázdne pole category_path [] znamená: "pre tento produkt neexistuje vhodná koncová kategória v strome".
`, len(products), strings.Join(productLines, "\n"), rootList, catTreeStr, createRule)

	var responseText string
	var err error
	if provider == "openai" {
		responseText, err = callOpenAIAPIV3(prompt, apiKey, model)
	} else {
		responseText, err = callClaudeAPIV3(prompt, apiKey, model)
	}
	if err != nil {
		// All failed — return error for each
		results := make([]batchResult, len(products))
		for i, p := range products {
			results[i] = batchResult{Index: p.Index, Error: err}
		}
		return results
	}

	// Parse batch response
	parsed := parseBatchAIResponse(responseText, len(products))
	results := make([]batchResult, len(products))
	for i, p := range products {
		if i < len(parsed) && parsed[i] != nil {
			results[i] = batchResult{Index: p.Index, Result: parsed[i]}
		} else {
			results[i] = batchResult{Index: p.Index, Error: fmt.Errorf("no AI result for product %d", i+1)}
		}
	}
	return results
}

func parseBatchAIResponse(text string, expectedCount int) []*AICategorizeResult {
	text = strings.TrimSpace(text)
	text = strings.TrimPrefix(text, "```json")
	text = strings.TrimPrefix(text, "```")
	text = strings.TrimSuffix(text, "```")
	text = strings.TrimSpace(text)

	// Find JSON array
	start := strings.Index(text, "[")
	end := strings.LastIndex(text, "]")
	if start >= 0 && end > start { text = text[start : end+1] }

	var items []struct {
		N            int      `json:"n"`
		CategoryPath []string `json:"category_path"`
		Brand        string   `json:"brand"`
		IsNew        bool     `json:"is_new"`
	}
	if err := json.Unmarshal([]byte(text), &items); err != nil {
		// Fallback: try parsing as single object
		single, singleErr := parseAIResponse(text)
		if singleErr == nil && single != nil {
			return []*AICategorizeResult{single}
		}
		return nil
	}

	results := make([]*AICategorizeResult, expectedCount)
	for _, item := range items {
		idx := item.N - 1
		if idx < 0 || idx >= expectedCount { continue }
		var cleanPath []string
		for _, name := range item.CategoryPath {
			name = strings.TrimSpace(name)
			if name != "" { cleanPath = append(cleanPath, name) }
		}
		if len(cleanPath) == 0 { cleanPath = []string{"Ostatné"} }
		results[idx] = &AICategorizeResult{
			CategoryPath: cleanPath,
			Brand: strings.TrimSpace(item.Brand),
			CreatedNewCategory: item.IsNew,
		}
	}
	return results
}

// ============================================================
// RESPONSE PARSING
// ============================================================

func parseAIResponse(text string) (*AICategorizeResult, error) {
	text = strings.TrimSpace(text)
	text = strings.TrimPrefix(text, "```json")
	text = strings.TrimPrefix(text, "```")
	text = strings.TrimSuffix(text, "```")
	text = strings.TrimSpace(text)
	start := strings.Index(text, "{")
	end := strings.LastIndex(text, "}")
	if start >= 0 && end > start { text = text[start : end+1] }
	var parsed struct {
		CategoryPath []string `json:"category_path"`
		Brand        string   `json:"brand"`
		IsNew        bool     `json:"is_new"`
	}
	if err := json.Unmarshal([]byte(text), &parsed); err != nil {
		return &AICategorizeResult{CategoryPath: []string{"Ostatné"}, Brand: ""}, nil
	}
	var cleanPath []string
	for _, name := range parsed.CategoryPath {
		name = strings.TrimSpace(name)
		if name != "" { cleanPath = append(cleanPath, name) }
	}
	if len(cleanPath) == 0 { cleanPath = []string{"Ostatné"} }
	return &AICategorizeResult{CategoryPath: cleanPath, Brand: strings.TrimSpace(parsed.Brand), CreatedNewCategory: parsed.IsNew}, nil
}

// ============================================================
// CATEGORY TREE CONTEXT
// ============================================================

func buildCategoryTreeContext(categories []map[string]interface{}) string {
	if len(categories) == 0 { return "Zatiaľ žiadne kategórie. Vytvor logický strom." }

	// Build parent lookup
	nameMap := make(map[string]string)  // id → name
	parentMap := make(map[string]string) // id → parent_id
	for _, cat := range categories {
		id := cat["id"].(string)
		name := cat["name"].(string)
		nameMap[id] = name
		if parentID, ok := cat["parent_id"].(*string); ok && parentID != nil && *parentID != "" {
			parentMap[id] = *parentID
		}
	}

	// Build full flat paths — oveľa kompaktnejšie ako indentovaný strom
	var paths []string
	seen := make(map[string]bool)
	for _, cat := range categories {
		id := cat["id"].(string)
		var parts []string
		current := id
		for {
			name, ok := nameMap[current]
			if !ok { break }
			parts = append([]string{name}, parts...)
			pid, hasPar := parentMap[current]
			if !hasPar { break }
			current = pid
		}
		if len(parts) > 0 {
			path := strings.Join(parts, " > ")
			if !seen[path] {
				seen[path] = true
				paths = append(paths, path)
			}
		}
	}

	// Limit — flat paths zmestia ~3000 kategórií do kontextu
	if len(paths) > 3000 {
		paths = paths[:3000]
		paths = append(paths, "...")
	}
	return strings.Join(paths, "\n")
}

func buildCategoryContext(categories []map[string]interface{}) string { return buildCategoryTreeContext(categories) }

// ============================================================
// BRANCH-FILTERED TREE — len relevantná vetva = 10-15x menej tokenov
// ============================================================

func buildBranchTreeContext(categories []map[string]interface{}, targetRoots []string) string {
	if len(targetRoots) == 0 || len(categories) == 0 {
		return buildCategoryTreeContext(categories)
	}

	// Build parent lookup
	nameMap := make(map[string]string)
	parentMap := make(map[string]string)
	childrenMap := make(map[string][]string)
	for _, cat := range categories {
		id := cat["id"].(string)
		name := cat["name"].(string)
		nameMap[id] = name
		if parentID, ok := cat["parent_id"].(*string); ok && parentID != nil && *parentID != "" {
			parentMap[id] = *parentID
			childrenMap[*parentID] = append(childrenMap[*parentID], id)
		}
	}

	// Find root category IDs matching target roots (fuzzy)
	var rootIDs []string
	targetLower := make(map[string]bool)
	for _, r := range targetRoots {
		targetLower[strings.ToLower(strings.TrimSpace(r))] = true
	}
	for _, cat := range categories {
		id := cat["id"].(string)
		name := cat["name"].(string)
		_, hasParent := parentMap[id]
		if !hasParent {
			nameLow := strings.ToLower(name)
			for target := range targetLower {
				if nameLow == target || strings.Contains(nameLow, target) || strings.Contains(target, nameLow) {
					rootIDs = append(rootIDs, id)
					break
				}
			}
		}
	}

	if len(rootIDs) == 0 {
		// Fallback: send just root names + first 2 levels
		return buildCompactTreeContext(categories)
	}

	// Collect all descendants of matched roots
	relevantIDs := make(map[string]bool)
	var collectDescendants func(id string)
	collectDescendants = func(id string) {
		relevantIDs[id] = true
		for _, childID := range childrenMap[id] {
			collectDescendants(childID)
		}
	}
	for _, rid := range rootIDs {
		collectDescendants(rid)
	}

	// Build paths only for relevant categories
	var paths []string
	seen := make(map[string]bool)
	for _, cat := range categories {
		id := cat["id"].(string)
		if !relevantIDs[id] { continue }
		var parts []string
		current := id
		for {
			name, ok := nameMap[current]
			if !ok { break }
			parts = append([]string{name}, parts...)
			pid, hasPar := parentMap[current]
			if !hasPar { break }
			current = pid
		}
		path := strings.Join(parts, " > ")
		if !seen[path] { seen[path] = true; paths = append(paths, path) }
	}

	// Add root-level list for context
	var rootNames []string
	for _, cat := range categories {
		id := cat["id"].(string)
		if _, hasP := parentMap[id]; !hasP {
			rootNames = append(rootNames, nameMap[id])
		}
	}

	header := fmt.Sprintf("ROOT KATEGÓRIE: %s\n\nRELEVANTNÁ VETVA (%d kategórií):\n", strings.Join(rootNames, ", "), len(paths))
	return header + strings.Join(paths, "\n")
}

// Compact tree — only root + 2 levels deep
func buildCompactTreeContext(categories []map[string]interface{}) string {
	nameMap := make(map[string]string)
	parentMap := make(map[string]string)
	for _, cat := range categories {
		id := cat["id"].(string)
		nameMap[id] = cat["name"].(string)
		if parentID, ok := cat["parent_id"].(*string); ok && parentID != nil && *parentID != "" {
			parentMap[id] = *parentID
		}
	}

	var paths []string
	seen := make(map[string]bool)
	for _, cat := range categories {
		id := cat["id"].(string)
		// Count depth
		depth := 0
		current := id
		for {
			pid, hasPar := parentMap[current]
			if !hasPar { break }
			depth++
			current = pid
		}
		if depth > 2 { continue } // Only root + 2 levels

		var parts []string
		current = id
		for {
			name, ok := nameMap[current]
			if !ok { break }
			parts = append([]string{name}, parts...)
			pid, hasPar := parentMap[current]
			if !hasPar { break }
			current = pid
		}
		path := strings.Join(parts, " > ")
		if !seen[path] { seen[path] = true; paths = append(paths, path) }
	}
	return strings.Join(paths, "\n")
}

// ============================================================
// PERSISTENT DB CACHE — feed kategória → category_id
// ============================================================

func (h *Handler) initFeedCategoryCache(ctx context.Context) {
	h.db.Pool.Exec(ctx, `CREATE TABLE IF NOT EXISTS feed_category_cache (
		feed_category TEXT PRIMARY KEY,
		category_id UUID NOT NULL,
		category_path TEXT,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
	)`)
}

func (h *Handler) getFeedCategoryFromDB(ctx context.Context, feedCategory string) string {
	var catID string
	h.db.Pool.QueryRow(ctx, `SELECT category_id FROM feed_category_cache WHERE feed_category = $1`, feedCategory).Scan(&catID)
	// Verify category still exists
	if catID != "" {
		var exists bool
		h.db.Pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM categories WHERE id = $1)`, catID).Scan(&exists)
		if !exists {
			h.db.Pool.Exec(ctx, `DELETE FROM feed_category_cache WHERE feed_category = $1`, feedCategory)
			return ""
		}
	}
	return catID
}

func (h *Handler) saveFeedCategoryToDB(ctx context.Context, feedCategory, categoryID string) {
	path := h.buildCategoryPath(ctx, categoryID)
	h.db.Pool.Exec(ctx, `INSERT INTO feed_category_cache (feed_category, category_id, category_path) 
		VALUES ($1, $2, $3) ON CONFLICT (feed_category) DO UPDATE SET category_id = $2, category_path = $3`, feedCategory, categoryID, path)
}

// Detect root category from feed parts using feedRootMapping
func detectRootFromFeed(feedParts []string) []string {
	if len(feedParts) == 0 { return nil }
	rootPart := strings.ToLower(strings.TrimSpace(feedParts[0]))
	
	// Try feedRootMapping
	if mapped, ok := feedRootMapping[rootPart]; ok {
		return []string{mapped}
	}
	// Try direct match
	return []string{feedParts[0]}
}

// ============================================================
// CATEGORY TREE OPERATIONS
// ============================================================

func (h *Handler) getExistingCategoryTree(ctx context.Context) []map[string]interface{} {
	rows, err := h.db.Pool.Query(ctx, `SELECT c.id, c.name, c.slug, c.parent_id, (SELECT cc.name FROM categories cc WHERE cc.id = c.parent_id) as parent_name FROM categories c ORDER BY c.name`)
	if err != nil { return nil }
	defer rows.Close()
	var cats []map[string]interface{}
	for rows.Next() {
		var id, name, slug string; var parentID, parentName *string
		rows.Scan(&id, &name, &slug, &parentID, &parentName)
		cats = append(cats, map[string]interface{}{"id": id, "name": name, "slug": slug, "parent_id": parentID, "parent_name": parentName})
	}
	return cats
}

func (h *Handler) findOrCreateCategoryPath(ctx context.Context, path []string, existingCats *[]map[string]interface{}, shopID string) string {
	if len(path) == 0 { return h.getOrCreateDefaultCat(ctx) }
	var parentID *string = nil
	for _, name := range path {
		name = strings.TrimSpace(name)
		if name == "" { continue }
		slug := generateSlug(name)
		var catID string; var found bool

		// 1. Presný match (slug alebo meno)
		if parentID == nil {
			err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE (slug = $1 OR LOWER(name) = LOWER($2)) AND parent_id IS NULL LIMIT 1`, slug, name).Scan(&catID)
			if err == nil { found = true }
		} else {
			err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE (slug = $1 OR LOWER(name) = LOWER($2)) AND parent_id = $3 LIMIT 1`, slug, name, *parentID).Scan(&catID)
			if err == nil { found = true }
		}

		// 2. Fuzzy match (≥80% podobnosť) — aby sa nevytvárali duplikáty
		if !found {
			fuzzyID := h.fuzzyFindCategoryDB(ctx, name, parentID)
			if fuzzyID != "" { catID = fuzzyID; found = true }
		}

		if found {
			parentID = &catID; continue
		}

		// 3. Vytvoriť novú
		newID := uuid.New().String()
		_, insertErr := h.db.Pool.Exec(ctx, `INSERT INTO categories (id, name, slug, parent_id, product_count, created_by_shop_id, is_active, created_at, updated_at) VALUES ($1, $2, $3, $4, 0, $5, true, NOW(), NOW())`, newID, name, slug, parentID, nilIfEmpty(shopID))
		if insertErr != nil {
			uniqueSlug := slug + "-" + newID[:8]
			_, insertErr = h.db.Pool.Exec(ctx, `INSERT INTO categories (id, name, slug, parent_id, product_count, created_by_shop_id, is_active, created_at, updated_at) VALUES ($1, $2, $3, $4, 0, $5, true, NOW(), NOW())`, newID, name, uniqueSlug, parentID, nilIfEmpty(shopID))
			if insertErr != nil {
				err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE LOWER(name) = LOWER($1) LIMIT 1`, name).Scan(&catID)
				if err == nil { parentID = &catID; continue }
				continue
			}
		}
		*existingCats = append(*existingCats, map[string]interface{}{"id": newID, "name": name, "slug": slug, "parent_id": parentID})
		parentID = &newID
	}
	if parentID != nil { return *parentID }
	return h.getOrCreateDefaultCat(ctx)
}

// findExistingCategoryOnly — hľadá existujúcu kategóriu, NIKDY nevytvára novú
//
// findOrCreateSmartPath — SMART mode: nájde root v strome, a ak treba,
// vytvára chýbajúce podkategórie. ALE root MUSÍ existovať!
// Toto je kľúčový rozdiel od Creative (ktorá vytvára aj nové rooty).
func (h *Handler) findOrCreateSmartPath(ctx context.Context, path []string, existingCats *[]map[string]interface{}, shopID string) string {
	if len(path) == 0 { return "" }
	
	// 1. Root MUSÍ existovať (presný alebo fuzzy match)
	rootName := strings.TrimSpace(path[0])
	rootSlug := generateSlug(rootName)
	var rootID string
	
	// Presný match root
	err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE (slug = $1 OR LOWER(name) = LOWER($2)) AND parent_id IS NULL LIMIT 1`, rootSlug, rootName).Scan(&rootID)
	if err != nil {
		// Fuzzy match root (≥80%)
		fuzzyID := h.fuzzyFindCategoryDB(ctx, rootName, nil)
		if fuzzyID != "" {
			rootID = fuzzyID
		} else {
			return "" // Root neexistuje → NEVYTVÁRAŤ, vráti prázdny
		}
	}
	
	if len(path) == 1 { return rootID }
	
	// 2. Pre zvyšné úrovne: hľadaj existujúce, ak neexistujú → vytvor
	parentID := rootID
	for _, name := range path[1:] {
		name = strings.TrimSpace(name)
		if name == "" { continue }
		slug := generateSlug(name)
		var catID string
		var found bool
		
		// Presný match pod rodičom
		if h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE (slug = $1 OR LOWER(name) = LOWER($2)) AND parent_id = $3 LIMIT 1`, slug, name, parentID).Scan(&catID) == nil {
			found = true
		}
		
		// Fuzzy match pod rodičom (≥80%)
		if !found {
			fuzzyID := h.fuzzyFindCategoryDB(ctx, name, &parentID)
			if fuzzyID != "" { catID = fuzzyID; found = true }
		}
		
		if found {
			parentID = catID
			continue
		}
		
		// Vytvoriť novú podkategóriu (pod existujúcim rodičom)
		newID := uuid.New().String()
		_, insertErr := h.db.Pool.Exec(ctx, `INSERT INTO categories (id, name, slug, parent_id, product_count, created_by_shop_id, is_active, created_at, updated_at) VALUES ($1, $2, $3, $4, 0, $5, true, NOW(), NOW())`, newID, name, slug, parentID, nilIfEmpty(shopID))
		if insertErr != nil {
			uniqueSlug := slug + "-" + newID[:8]
			h.db.Pool.Exec(ctx, `INSERT INTO categories (id, name, slug, parent_id, product_count, created_by_shop_id, is_active, created_at, updated_at) VALUES ($1, $2, $3, $4, 0, $5, true, NOW(), NOW())`, newID, name, uniqueSlug, parentID, nilIfEmpty(shopID))
		}
		*existingCats = append(*existingCats, map[string]interface{}{"id": newID, "name": name, "slug": slug, "parent_id": &parentID})
		parentID = newID
	}
	return parentID
}
// Vracia ID poslednej nájdenej kategórie v ceste, alebo "" ak nenájde
func (h *Handler) findExistingCategoryOnly(ctx context.Context, path []string) string {
	if len(path) == 0 { return "" }
	var parentID *string = nil
	var lastFoundID string
	matchedLevels := 0
	totalLevels := 0

	for _, name := range path {
		name = strings.TrimSpace(name)
		if name == "" { continue }
		totalLevels++
		slug := generateSlug(name)
		var catID string
		var found bool

		// 1. Presný match (slug alebo name) pod rodičom
		if parentID == nil {
			err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE (slug = $1 OR LOWER(name) = LOWER($2)) AND parent_id IS NULL LIMIT 1`, slug, name).Scan(&catID)
			if err == nil { found = true }
		} else {
			err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE (slug = $1 OR LOWER(name) = LOWER($2)) AND parent_id = $3 LIMIT 1`, slug, name, *parentID).Scan(&catID)
			if err == nil { found = true }
		}

		// 2. Fuzzy match (≥85%) pod rodičom — BEZPEČNÉ, rovnaká vetva
		if !found {
			fuzzyID := h.fuzzyFindCategoryDB(ctx, name, parentID)
			if fuzzyID != "" { catID = fuzzyID; found = true }
		}

		// STOP — žiadny globálny match! Radšej nezaradiť ako zle zaradiť
		if !found { break }
		lastFoundID = catID
		parentID = &catID
		matchedLevels++
	}

	// PRAVIDLO: LEAF MUSÍ EXISTOVAŤ
	// Feed "Hrácky | Hádanky | 3D puzzle" (3 úrovne) ale strom má len "Hádanky" (2 matchnuté)
	// → Vrátime "" namiesto "Hádanky", nech to zaradí kreatívna správne
	if matchedLevels < totalLevels {
		return "" // Partial match = nezaradiť
	}

	// PRAVIDLO 2: NIKDY nevrátiť ROOT-only match (hĺbka 1) keď boli navrhnuté 2+ úrovne
	// Toto zabraňuje zaradeniu "3D puzzle" → "Hračky a hry" (root)
	if matchedLevels == 1 && totalLevels >= 2 {
		return "" // Root-only match pre viacúrovňový path = nezaradiť
	}

	// PRAVIDLO 3: Ak matchedLevels == 1 a totalLevels == 1, skontroluj či to nie je len root
	if matchedLevels == 1 && parentID != nil {
		// Skontroluj či matchnutá kategória je root (parent_id IS NULL)
		var checkParent *string
		h.db.Pool.QueryRow(ctx, `SELECT parent_id FROM categories WHERE id = $1`, lastFoundID).Scan(&checkParent)
		if checkParent == nil {
			// Je to root kategória a AI navrhla len 1 úroveň — podozrivé, radšej nezaradiť
			return ""
		}
	}

	return lastFoundID
}

// findCategoryForMode — podľa režimu buď len hľadá, alebo aj vytvára
func (h *Handler) findCategoryForMode(ctx context.Context, path []string, creative bool, existingCats *[]map[string]interface{}, shopID string) string {
	if creative {
		return h.findOrCreateCategoryPath(ctx, path, existingCats, shopID)
	}
	return h.findExistingCategoryOnly(ctx, path)
}

func (h *Handler) createSubcategoriesFromIndex(ctx context.Context, parentID string, parts []string, startIdx int, shopID string) string {
	createParentID := parentID
	for j := startIdx; j < len(parts); j++ {
		subName := strings.TrimSpace(parts[j])
		if subName == "" { continue }

		// 1. Presný match
		var existingChildID string
		if h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE LOWER(name) = LOWER($1) AND parent_id = $2 LIMIT 1`, subName, createParentID).Scan(&existingChildID) == nil {
			createParentID = existingChildID; continue
		}

		// 2. Fuzzy match (≥80%) — "Slúchadlá" vs "Sluchadla"
		fuzzyID := h.fuzzyFindCategoryDB(ctx, subName, &createParentID)
		if fuzzyID != "" {
			createParentID = fuzzyID; continue
		}

		// 3. Vytvoriť novú
		newID := uuid.New().String()
		slug := generateSlug(subName)
		var slugExists bool
		h.db.Pool.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM categories WHERE slug = $1)", slug).Scan(&slugExists)
		if slugExists { slug = slug + "-" + newID[:8] }
		h.db.Pool.Exec(ctx, `INSERT INTO categories (id, name, slug, parent_id, is_active, product_count, created_by_shop_id, created_at, updated_at) VALUES ($1, $2, $3, $4, true, 0, $5, NOW(), NOW())`,
			newID, subName, slug, createParentID, nilIfEmpty(shopID))
		createParentID = newID
	}
	return createParentID
}

func nilIfEmpty(s string) interface{} { if s == "" { return nil }; return s }

func (h *Handler) getOrCreateDefaultCat(ctx context.Context) string {
	var catID string
	err := h.db.Pool.QueryRow(ctx, `SELECT id FROM categories WHERE slug = 'ostatne' LIMIT 1`).Scan(&catID)
	if err == nil { return catID }
	newID := uuid.New().String()
	h.db.Pool.Exec(ctx, `INSERT INTO categories (id, name, slug, parent_id, product_count, is_active, created_at, updated_at) VALUES ($1, 'Ostatné', 'ostatne', NULL, 0, true, NOW(), NOW())`, newID)
	return newID
}

func getCategoryAncestorNames(catID string, categories []map[string]interface{}) []string {
	catMap := make(map[string]map[string]interface{})
	for _, c := range categories { catMap[c["id"].(string)] = c }
	var path []string; currentID := catID; visited := make(map[string]bool)
	for {
		if visited[currentID] { break }; visited[currentID] = true
		cat, ok := catMap[currentID]; if !ok { break }
		path = append([]string{cat["name"].(string)}, path...)
		parentID, _ := cat["parent_id"].(*string)
		if parentID == nil || *parentID == "" { break }; currentID = *parentID
	}
	return path
}

func (h *Handler) getFeedCategoryForProduct(ctx context.Context, productID string) string {
	var feedCategory string
	err := h.db.Pool.QueryRow(ctx, `SELECT COALESCE(o.category, '') FROM offers o WHERE o.product_id = $1 AND o.category IS NOT NULL AND o.category != '' LIMIT 1`, productID).Scan(&feedCategory)
	if err != nil || feedCategory == "" { return "" }
	return feedCategory
}

// ============================================================
// SINGLE PRODUCT AI CATEGORIZATION
// ============================================================

func (h *Handler) CategorizeProductByID(ctx context.Context, productID string) (string, error) {
	var title, description, brand string
	err := h.db.Pool.QueryRow(ctx, `SELECT title, COALESCE(description, ''), COALESCE(brand, '') FROM products WHERE id = $1`, productID).Scan(&title, &description, &brand)
	if err != nil { return "", fmt.Errorf("produkt nenájdený: %v", err) }
	var existingCatID *string
	h.db.Pool.QueryRow(ctx, `SELECT category_id FROM products WHERE id = $1`, productID).Scan(&existingCatID)
	if existingCatID != nil && *existingCatID != "" { return *existingCatID, nil }
	var prodShopID string
	h.db.Pool.QueryRow(ctx, `SELECT shop_id FROM offers WHERE product_id = $1 LIMIT 1`, productID).Scan(&prodShopID)
	provider := h.getAISetting(ctx, "ai_provider")
	if provider == "" { provider = "openai" }
	model := h.getActiveModel(ctx, provider)
	var apiKey string
	if provider == "openai" { apiKey = h.getAISetting(ctx, "openai_api_key") } else { apiKey = h.getAISetting(ctx, "anthropic_api_key") }
	if apiKey == "" { return "", fmt.Errorf("API kľúč nie je nastavený") }

	feedCategory := h.getFeedCategoryForProduct(ctx, productID)
	existingCategories := h.getExistingCategoryTree(ctx)

	if feedCategory != "" {
		feedParts := normalizeFeedParts(feedCategory)
		catID := h.matchFeedPathToTree(ctx, feedParts, existingCategories, prodShopID)
		if catID != "" { h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1, updated_at = NOW() WHERE id = $2`, catID, productID); return catID, nil }
		if len(feedParts) > 0 {
			rootID := h.findRootCategory(feedParts[0], existingCategories)
			if rootID != "" {
				catID = h.findExistingCategoryOnly(ctx, feedParts)
				h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1, updated_at = NOW() WHERE id = $2`, catID, productID); return catID, nil
			}
		}
		aiResult, aiErr := h.aiCategorizeV3(provider, apiKey, model, title, feedCategory, feedParts, "", existingCategories)
		if aiErr != nil || aiResult == nil || len(aiResult.CategoryPath) == 0 {
			catID = h.findExistingCategoryOnly(ctx, feedParts)
			if catID != "" {
				h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1, updated_at = NOW() WHERE id = $2`, catID, productID)
			}
			return catID, nil
		}
		validatedPath := validateCategoryPathV3(aiResult.CategoryPath, feedParts)
		categoryID := h.findExistingCategoryOnly(ctx, validatedPath)
		if categoryID != "" {
			h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1, updated_at = NOW() WHERE id = $2`, categoryID, productID)
		}
		if aiResult.Brand != "" && brand == "" { h.db.Pool.Exec(ctx, `UPDATE products SET brand = $1 WHERE id = $2 AND (brand IS NULL OR brand = '')`, aiResult.Brand, productID) }
		return categoryID, nil
	}

	aiResult, aiErr := h.aiCategorizeV3(provider, apiKey, model, title, "", nil, description, existingCategories)
	if aiErr != nil { return "", aiErr }
	if aiResult == nil || len(aiResult.CategoryPath) == 0 { return "", fmt.Errorf("AI prázdny") }
	categoryID := h.findExistingCategoryOnly(ctx, aiResult.CategoryPath)
	if categoryID != "" {
		h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1, updated_at = NOW() WHERE id = $2`, categoryID, productID)
		if aiResult.Brand != "" && brand == "" { h.db.Pool.Exec(ctx, `UPDATE products SET brand = $1 WHERE id = $2 AND (brand IS NULL OR brand = '')`, aiResult.Brand, productID) }
	}
	return categoryID, nil
}

// ============================================================
// DISPLAY MODE + HELPERS
// ============================================================

func (h *Handler) AdminGetDisplayModeStats(c *fiber.Ctx) error {
	ctx := context.Background()
	var totalShops, freeShops, paidShops, totalOffers, freeOffers, paidOffers, matchedOffers, unmatchedOffers int
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM shops WHERE shop_status = 'active'`).Scan(&totalShops)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM shops WHERE shop_status = 'active' AND COALESCE(display_mode, 'free') = 'free'`).Scan(&freeShops)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM shops WHERE shop_status = 'active' AND display_mode IN ('paid', 'cpc')`).Scan(&paidShops)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE status = 'active'`).Scan(&totalOffers)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers o JOIN shops s ON o.shop_id = s.id WHERE o.status = 'active' AND COALESCE(s.display_mode, 'free') = 'free'`).Scan(&freeOffers)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers o JOIN shops s ON o.shop_id = s.id WHERE o.status = 'active' AND s.display_mode IN ('paid', 'cpc')`).Scan(&paidOffers)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NOT NULL`).Scan(&matchedOffers)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM offers WHERE product_id IS NULL`).Scan(&unmatchedOffers)
	return c.JSON(fiber.Map{"success": true, "data": fiber.Map{
		"shops": fiber.Map{"total": totalShops, "free": freeShops, "paid": paidShops},
		"offers": fiber.Map{"total": totalOffers, "free": freeOffers, "paid": paidOffers},
		"matching": fiber.Map{"matched": matchedOffers, "unmatched": unmatchedOffers}}})
}

func truncateTitle(title string, maxLen int) string {
	words := strings.Fields(title)
	result := ""
	for _, w := range words {
		if len(result)+len(w)+1 > maxLen { break }
		if result != "" { result += " " }
		result += w
	}
	if result == "" && len(title) > 0 { if len(title) > maxLen { return title[:maxLen] }; return title }
	return result
}

func minInt(a, b int) int { if a < b { return a }; return b }

func (h *Handler) updateJobStats(ctx context.Context, jobID uuid.UUID, processed, matched, newProducts, newCategories, errors int) {
	h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET processed = $2, matched = $3, new_products = $4, new_categories = $5, errors = $6 WHERE id = $1`, jobID, processed, matched, newProducts, newCategories, errors)
}

func (h *Handler) updateJobError(ctx context.Context, jobID uuid.UUID, errMsg string) {
	h.db.Pool.Exec(ctx, `UPDATE ai_categorization_jobs SET status = 'failed', error_log = $2, finished_at = NOW() WHERE id = $1`, jobID, errMsg)
}

func (h *Handler) buildCategoryPath(ctx context.Context, categoryID string) string {
	var parts []string; currentID := categoryID
	for i := 0; i < 10; i++ {
		var name string; var parentID *string
		err := h.db.Pool.QueryRow(ctx, `SELECT name, parent_id FROM categories WHERE id = $1`, currentID).Scan(&name, &parentID)
		if err != nil { break }; parts = append([]string{name}, parts...)
		if parentID == nil { break }; currentID = *parentID
	}
	return strings.Join(parts, " > ")
}

// ============================================================
// REPORT + CSV + CLEANUP
// ============================================================

func (h *Handler) AdminAICategorizationReport(c *fiber.Ctx) error {
	ctx := context.Background()
	page := c.QueryInt("page", 1); perPage := c.QueryInt("per_page", 50)
	matchType := c.Query("match_type", ""); shopID := c.Query("shop_id", "")
	offset := (page - 1) * perPage
	where := "WHERE o.product_id IS NOT NULL"; args := []interface{}{}; argIdx := 1
	if matchType != "" && matchType != "all" { where += fmt.Sprintf(" AND o.match_type = $%d", argIdx); args = append(args, matchType); argIdx++ }
	if shopID != "" { where += fmt.Sprintf(" AND o.shop_id = $%d", argIdx); args = append(args, shopID); argIdx++ }
	var total int
	h.db.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT COUNT(*) FROM offers o JOIN products p ON o.product_id=p.id %s`, where), args...).Scan(&total)
	dataQ := fmt.Sprintf(`SELECT o.id, o.title, COALESCE(o.category,''), COALESCE(o.match_type,''), p.id, p.title, p.slug, COALESCE(c.id::text,''), COALESCE(c.name,''), COALESCE(p.brand,''), COALESCE(o.price,0), COALESCE(s.shop_name,''), o.created_at::text, p.created_at::text FROM offers o JOIN products p ON o.product_id=p.id LEFT JOIN categories c ON p.category_id=c.id LEFT JOIN shops s ON o.shop_id=s.id %s ORDER BY o.created_at DESC LIMIT $%d OFFSET $%d`, where, argIdx, argIdx+1)
	args = append(args, perPage, offset)
	rows, err := h.db.Pool.Query(ctx, dataQ, args...)
	if err != nil { return c.Status(500).JSON(fiber.Map{"success": false, "error": err.Error()}) }
	defer rows.Close()
	var items []fiber.Map; catPathCache := map[string]string{}
	for rows.Next() {
		var oID, oTitle, feedCat, mType, pID, pTitle, pSlug, cID, cName, brand, shopName, oCreated, pCreated string; var price float64
		rows.Scan(&oID, &oTitle, &feedCat, &mType, &pID, &pTitle, &pSlug, &cID, &cName, &brand, &price, &shopName, &oCreated, &pCreated)
		fp := ""
		if cID != "" { if cached, ok := catPathCache[cID]; ok { fp = cached } else { fp = h.buildCategoryPath(ctx, cID); if fp == "" { fp = cName }; catPathCache[cID] = fp } }
		items = append(items, fiber.Map{"offer_id": oID, "offer_title": oTitle, "feed_category": feedCat, "match_type": mType, "product_id": pID, "product_title": pTitle, "product_slug": pSlug, "category_id": cID, "category_name": cName, "category_path": fp, "brand": brand, "price": price, "shop_name": shopName, "offer_created": oCreated, "product_created": pCreated})
	}
	sw := ""; sa := []interface{}{}
	if shopID != "" { sw = " AND shop_id = $1"; sa = []interface{}{shopID} }
	var tCreated, tMatched, tFulltext, tProducts, tCategories, tNewCats int
	h.db.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT COUNT(*) FROM offers WHERE match_type='created'%s`, sw), sa...).Scan(&tCreated)
	h.db.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT COUNT(*) FROM offers WHERE match_type='matched'%s`, sw), sa...).Scan(&tMatched)
	h.db.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT COUNT(*) FROM offers WHERE match_type='fulltext'%s`, sw), sa...).Scan(&tFulltext)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM products`).Scan(&tProducts)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM categories`).Scan(&tCategories)
	h.db.Pool.QueryRow(ctx, `SELECT COUNT(*) FROM categories WHERE created_at > NOW()-INTERVAL '24 hours'`).Scan(&tNewCats)
	return c.JSON(fiber.Map{"success": true, "data": items, "total": total, "page": page, "per_page": perPage, "total_pages": (total + perPage - 1) / perPage,
		"stats": fiber.Map{"total_created": tCreated, "total_matched": tMatched, "total_fulltext": tFulltext, "total_products": tProducts, "total_categories": tCategories, "new_categories": tNewCats}})
}

func (h *Handler) AdminAICategorizationReportCSV(c *fiber.Ctx) error {
	ctx := context.Background(); shopID := c.Query("shop_id", "")
	format := c.Query("format", "csv") // csv alebo xlsx
	h.db.Pool.Exec(ctx, `ALTER TABLE categories ADD COLUMN IF NOT EXISTS created_by_shop_id UUID`)
	
	var data []reportRow
	catPathCache := map[string]string{}
	scanErrors := 0

	// ČASŤ 1: Zaradené ponuky (s product_id)
	where1 := "WHERE o.product_id IS NOT NULL"; args1 := []interface{}{}
	if shopID != "" { where1 += " AND o.shop_id = $1"; args1 = append(args1, shopID) }
	q1 := fmt.Sprintf(`SELECT o.title, COALESCE(o.category,''), COALESCE(o.match_type,''), 
		p.title, COALESCE(c.name,''), COALESCE(p.brand,''), COALESCE(o.price,0), 
		COALESCE(p.category_id::text,''), COALESCE(s.shop_name,''), COALESCE(o.created_at::text,''),
		CASE WHEN c.created_by_shop_id IS NOT NULL THEN 'AI vytvorená' ELSE 'Existujúca' END,
		COALESCE(o.ai_suggested_category,'')
		FROM offers o JOIN products p ON o.product_id=p.id 
		LEFT JOIN categories c ON p.category_id=c.id 
		LEFT JOIN shops s ON o.shop_id=s.id %s ORDER BY o.created_at DESC LIMIT 100000`, where1)
	rows1, err1 := h.db.Pool.Query(ctx, q1, args1...)
	if err1 == nil {
		defer rows1.Close()
		for rows1.Next() {
			var r reportRow
			var catID, createdAt, aiSuggested string
			if rows1.Scan(&r.Title, &r.FeedCat, &r.MatchType, &r.PTitle, &r.CatName, &r.Brand, &r.Price, &catID, &r.ShopName, &createdAt, &r.CatOrigin, &aiSuggested) != nil { scanErrors++; continue }
			r.FullPath = r.CatName
			if catID != "" {
				if cached, ok := catPathCache[catID]; ok { r.FullPath = cached } else {
					r.FullPath = h.buildCategoryPath(ctx, catID); if r.FullPath == "" { r.FullPath = r.CatName }
					catPathCache[catID] = r.FullPath
				}
			}
			r.MatchDetail = h.matchTypeLabel(r.MatchType)
			r.Date = createdAt; if len(r.Date) > 19 { r.Date = r.Date[:19] }
			data = append(data, r)
		}
	}

	// ČASŤ 2: Nezaradené ponuky (ai_unmatched, bez product_id)
	where2 := "WHERE o.product_id IS NULL AND o.match_type = 'ai_unmatched'"; args2 := []interface{}{}
	if shopID != "" { where2 += " AND o.shop_id = $1"; args2 = append(args2, shopID) }
	q2 := fmt.Sprintf(`SELECT o.title, COALESCE(o.category,''), 'ai_unmatched', 
		o.title, '', '', COALESCE(o.price,0), 
		'', COALESCE(s.shop_name,''), COALESCE(o.created_at::text,''), 'Nezaradené',
		COALESCE(o.ai_suggested_category,'')
		FROM offers o LEFT JOIN shops s ON o.shop_id=s.id %s ORDER BY o.title ASC LIMIT 100000`, where2)
	rows2, err2 := h.db.Pool.Query(ctx, q2, args2...)
	if err2 == nil {
		defer rows2.Close()
		for rows2.Next() {
			var r reportRow
			var catID, createdAt, aiSuggested string
			if rows2.Scan(&r.Title, &r.FeedCat, &r.MatchType, &r.PTitle, &r.CatName, &r.Brand, &r.Price, &catID, &r.ShopName, &createdAt, &r.CatOrigin, &aiSuggested) != nil { scanErrors++; continue }
			r.FullPath = aiSuggested // Pre nezaradené ukáž AI návrh
			if r.FullPath == "" { r.FullPath = "❌ Bez kategórie" }
			r.MatchDetail = "❌ Nezaradené (čaká na Kreatívnu)"
			r.Date = createdAt; if len(r.Date) > 19 { r.Date = r.Date[:19] }
			data = append(data, r)
		}
	}

	if len(data) == 0 {
		return c.Status(404).JSON(fiber.Map{"success": false, "error": fmt.Sprintf("Žiadne dáta na export (scanErrors=%d). Skúste importovať feed a spustiť kategorizáciu.", scanErrors)})
	}

	headers := []string{"Ponuka", "Feed kategória", "Typ zaradenia", "Detail", "Produkt", "Kategória", "Zaradená cesta", "Typ kategórie", "Značka", "Cena", "Obchod", "Dátum"}

	if format == "xlsx" {
		xlsxData := h.generateXLSX(headers, data)
		if len(xlsxData) == 0 {
			return c.Status(500).JSON(fiber.Map{"success": false, "error": "Chyba pri generovaní XLSX"})
		}
		c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
		c.Set("Content-Disposition", "attachment; filename=ai-kategorizacia-report.xlsx")
		c.Set("Content-Length", fmt.Sprintf("%d", len(xlsxData)))
		return c.Send(xlsxData)
	}

	// CSV fallback
	esc := func(s string) string { return strings.ReplaceAll(strings.ReplaceAll(s, ";", ","), "\n", " ") }
	csv := "\xEF\xBB\xBF" + strings.Join(headers, ";") + "\n"
	for _, r := range data {
		csv += fmt.Sprintf("%s;%s;%s;%s;%s;%s;%s;%s;%s;%.2f;%s;%s\n",
			esc(r.Title), esc(r.FeedCat), esc(r.MatchDetail), esc(r.MatchDetail), esc(r.PTitle), esc(r.CatName), esc(r.FullPath), r.CatOrigin, esc(r.Brand), r.Price, esc(r.ShopName), r.Date)
	}
	c.Set("Content-Type", "text/csv; charset=utf-8"); c.Set("Content-Disposition", "attachment; filename=ai-kategorizacia-report.csv")
	return c.SendString(csv)
}

func (h *Handler) matchTypeLabel(mt string) string {
	switch mt {
	case "feed_match": return "📁 Feed match"
	case "cache_match": return "💾 Cache"
	case "ai_zaradená": return "🤖 AI → existujúca kategória"
	case "ai_vytvorená_kat": return "🆕 AI → nová kategória"
	case "ai_unmatched": return "❌ Nezaradené"
	case "ai_created": return "🤖 AI zaradená"
	case "created": return "AI vytvorený produkt"
	case "matched": return "EAN párovanie"
	case "fulltext": return "Fulltext párovanie"
	case "feed_branch": return "📁 Feed vetva"
	case "ai_translated": return "AI preklad"
	case "feed_fallback": return "📂 Feed fallback"
	default: return mt
	}
}

// generateXLSX creates XLSX file without external dependencies (XLSX = ZIP with XML)
func (h *Handler) generateXLSX(headers []string, data []reportRow) []byte {
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)

	escXML := func(s string) string {
		s = strings.ReplaceAll(s, "&", "&amp;")
		s = strings.ReplaceAll(s, "<", "&lt;")
		s = strings.ReplaceAll(s, ">", "&gt;")
		s = strings.ReplaceAll(s, "\"", "&quot;")
		return s
	}
	colRef := func(col, row int) string {
		return string(rune('A'+col)) + fmt.Sprintf("%d", row)
	}

	// [Content_Types].xml
	ct, _ := zw.Create("[Content_Types].xml")
	ct.Write([]byte(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>`))

	// _rels/.rels
	rels, _ := zw.Create("_rels/.rels")
	rels.Write([]byte(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`))

	// xl/_rels/workbook.xml.rels
	wbr, _ := zw.Create("xl/_rels/workbook.xml.rels")
	wbr.Write([]byte(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>`))

	// xl/workbook.xml
	wb, _ := zw.Create("xl/workbook.xml")
	wb.Write([]byte(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="AI Report" sheetId="1" r:id="rId1"/></sheets></workbook>`))

	// xl/styles.xml (bold header + number format)
	st, _ := zw.Create("xl/styles.xml")
	st.Write([]byte(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF4472C4"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="3">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment horizontal="center"/></xf>
<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
</cellXfs>
</styleSheet>`))

	// Build shared strings
	var ssb strings.Builder
	ssIdx := map[string]int{}
	ssCount := 0
	addSS := func(s string) int {
		if idx, ok := ssIdx[s]; ok { return idx }
		ssIdx[s] = ssCount
		ssb.WriteString(`<si><t>` + escXML(s) + `</t></si>`)
		ssCount++
		return ssCount - 1
	}

	// Pre-add all strings
	for _, h := range headers { addSS(h) }
	for _, r := range data {
		addSS(r.Title); addSS(r.FeedCat); addSS(r.MatchDetail); addSS(r.MatchDetail)
		addSS(r.PTitle); addSS(r.CatName); addSS(r.FullPath); addSS(r.CatOrigin)
		addSS(r.Brand); addSS(r.ShopName); addSS(r.Date)
	}

	// xl/sharedStrings.xml
	ss, _ := zw.Create("xl/sharedStrings.xml")
	ss.Write([]byte(fmt.Sprintf(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="%d" uniqueCount="%d">%s</sst>`, ssCount, ssCount, ssb.String())))

	// xl/worksheets/sheet1.xml
	sh, _ := zw.Create("xl/worksheets/sheet1.xml")
	sh.Write([]byte(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<cols>`))
	colWidths := []int{35, 30, 15, 20, 35, 20, 40, 15, 15, 10, 15, 18}
	for i, w := range colWidths {
		sh.Write([]byte(fmt.Sprintf(`<col min="%d" max="%d" width="%d" customWidth="1"/>`, i+1, i+1, w)))
	}
	sh.Write([]byte(`</cols><sheetData>`))

	// Header row
	sh.Write([]byte(`<row r="1">`))
	for i, h := range headers {
		sh.Write([]byte(fmt.Sprintf(`<c r="%s" t="s" s="1"><v>%d</v></c>`, colRef(i, 1), addSS(h))))
	}
	sh.Write([]byte(`</row>`))

	// Data rows
	for ri, r := range data {
		rowNum := ri + 2
		sh.Write([]byte(fmt.Sprintf(`<row r="%d">`, rowNum)))
		vals := []string{r.Title, r.FeedCat, r.MatchDetail, r.MatchDetail, r.PTitle, r.CatName, r.FullPath, r.CatOrigin, r.Brand}
		for ci, v := range vals {
			sh.Write([]byte(fmt.Sprintf(`<c r="%s" t="s"><v>%d</v></c>`, colRef(ci, rowNum), addSS(v))))
		}
		// Price as number
		sh.Write([]byte(fmt.Sprintf(`<c r="%s" s="2"><v>%.2f</v></c>`, colRef(9, rowNum), r.Price)))
		// Shop, Date as strings
		sh.Write([]byte(fmt.Sprintf(`<c r="%s" t="s"><v>%d</v></c>`, colRef(10, rowNum), addSS(r.ShopName))))
		sh.Write([]byte(fmt.Sprintf(`<c r="%s" t="s"><v>%d</v></c>`, colRef(11, rowNum), addSS(r.Date))))
		sh.Write([]byte(`</row>`))
	}
	sh.Write([]byte(`</sheetData></worksheet>`))

	zw.Close()
	return buf.Bytes()
}


// ============================================================
// AI TREE AUDIT — kontrola stromu kategórií
// ============================================================

type AuditIssue struct {
	ID         string `json:"id"`
	CategoryID string `json:"category_id"`
	Name       string `json:"name"`
	FullPath   string `json:"full_path"`
	Type       string `json:"type"`       // "foreign", "duplicate", "illogical", "empty_branch", "too_deep"
	Severity   string `json:"severity"`   // "high", "medium", "low"
	Detail     string `json:"detail"`
	Suggestion string `json:"suggestion"` // AI navrhované riešenie
}

func (h *Handler) AdminAICategoryAudit(c *fiber.Ctx) error {
	ctx := context.Background()
	provider := c.Query("provider", "") // "openai" alebo "anthropic" — ak prázdne, použije default

	// Načítaj celý strom kategórií
	rows, err := h.db.Pool.Query(ctx, `
		SELECT c.id, c.name, c.slug, COALESCE(c.parent_id::text, ''), c.product_count,
			(SELECT COUNT(*) FROM categories ch WHERE ch.parent_id = c.id) as child_count
		FROM categories c ORDER BY c.name
	`)
	if err != nil { return c.Status(500).JSON(fiber.Map{"success": false, "error": err.Error()}) }
	defer rows.Close()

	type catInfo struct {
		ID, Name, Slug, ParentID string
		ProductCount, ChildCount int
	}
	var cats []catInfo
	catMap := map[string]catInfo{}
	nameCount := map[string][]string{} // name → [ids]

	for rows.Next() {
		var ci catInfo
		rows.Scan(&ci.ID, &ci.Name, &ci.Slug, &ci.ParentID, &ci.ProductCount, &ci.ChildCount)
		cats = append(cats, ci)
		catMap[ci.ID] = ci
		lower := strings.ToLower(ci.Name)
		nameCount[lower] = append(nameCount[lower], ci.ID)
	}

	// Zostav cesty
	buildPath := func(id string) string {
		var parts []string
		current := id
		for i := 0; i < 10; i++ {
			ci, ok := catMap[current]
			if !ok { break }
			parts = append([]string{ci.Name}, parts...)
			if ci.ParentID == "" { break }
			current = ci.ParentID
		}
		return strings.Join(parts, " > ")
	}

	var issues []AuditIssue
	issueID := 0

	// === CHECK 1: Cudzie názvy (nie slovenčina) ===
	foreignPatterns := map[string]string{
		// Holandské
		"en ": "holandčina", "voor ": "holandčina", " en ": "holandčina",
		"van ": "holandčina", "met ": "holandčina", " bij ": "holandčina",
		// Anglické
		" and ": "angličtina", " for ": "angličtina", " with ": "angličtina",
		" the ": "angličtina", "cleaning": "angličtina", "accessories": "angličtina",
		"supplies": "angličtina", "equipment": "angličtina", "products": "angličtina",
		// Nemecké
		"und ": "nemčina", "für ": "nemčina", "zubehör": "nemčina",
	}
	// Slovak indicators
	slovakIndicators := []string{"á", "é", "í", "ó", "ú", "ý", "č", "ď", "ľ", "ň", "š", "ť", "ž", "ô", "ä"}
	isSlovak := func(name string) bool {
		for _, ind := range slovakIndicators {
			if strings.Contains(name, ind) { return true }
		}
		return false
	}

	for _, ci := range cats {
		name := ci.Name
		lower := strings.ToLower(name)

		// Foreign check
		if !isSlovak(name) {
			for pattern, lang := range foreignPatterns {
				if strings.Contains(lower, pattern) {
					issueID++
					issues = append(issues, AuditIssue{
						ID: fmt.Sprintf("ISS-%d", issueID), CategoryID: ci.ID,
						Name: name, FullPath: buildPath(ci.ID),
						Type: "foreign", Severity: "high",
						Detail: fmt.Sprintf("Pravdepodobne %s: \"%s\"", lang, name),
						Suggestion: "", // AI doplní neskôr
					})
					break
				}
			}
		}

		// === CHECK 2: Duplicity ===
		if ids := nameCount[lower]; len(ids) > 1 {
			// Len prvý výskyt reportuj
			if ids[0] == ci.ID {
				paths := []string{}
				for _, dupID := range ids {
					paths = append(paths, buildPath(dupID))
				}
				issueID++
				issues = append(issues, AuditIssue{
					ID: fmt.Sprintf("ISS-%d", issueID), CategoryID: ci.ID,
					Name: name, FullPath: strings.Join(paths, " | "),
					Type: "duplicate", Severity: "medium",
					Detail: fmt.Sprintf("Kategória \"%s\" existuje %dx na rôznych miestach", name, len(ids)),
					Suggestion: "Zvážiť zlúčenie duplicitných kategórií",
				})
			}
		}

		// === CHECK 3: Prázdne vetvy (0 produktov, 0 detí) ===
		if ci.ProductCount == 0 && ci.ChildCount == 0 {
			issueID++
			issues = append(issues, AuditIssue{
				ID: fmt.Sprintf("ISS-%d", issueID), CategoryID: ci.ID,
				Name: name, FullPath: buildPath(ci.ID),
				Type: "empty_branch", Severity: "low",
				Detail: "Prázdna kategória bez produktov a podkategórií",
				Suggestion: "Zmazať alebo presunúť pod relevantnú kategóriu",
			})
		}

		// === CHECK 4: Príliš hlboký strom (>5 úrovní) ===
		depth := 0
		current := ci.ID
		for i := 0; i < 10; i++ {
			p, ok := catMap[current]
			if !ok || p.ParentID == "" { break }
			current = p.ParentID
			depth++
		}
		if depth > 4 {
			issueID++
			issues = append(issues, AuditIssue{
				ID: fmt.Sprintf("ISS-%d", issueID), CategoryID: ci.ID,
				Name: name, FullPath: buildPath(ci.ID),
				Type: "too_deep", Severity: "medium",
				Detail: fmt.Sprintf("Kategória je %d úrovní hlboko (max odporúčané: 4)", depth+1),
				Suggestion: "Zjednodušiť hierarchiu — presunúť o úroveň vyššie",
			})
		}
	}

	// === AI PREKLAD cudzích názvov ===
	foreignIssues := []AuditIssue{}
	for i := range issues {
		if issues[i].Type == "foreign" { foreignIssues = append(foreignIssues, issues[i]) }
	}

	if len(foreignIssues) > 0 && len(foreignIssues) <= 100 {
		auditProvider := provider
		if auditProvider == "" { auditProvider = h.getAISetting(ctx, "ai_provider") }
		if auditProvider == "" { auditProvider = "openai" }
		apiKey := ""
		if auditProvider == "openai" { apiKey = h.getAISetting(ctx, "openai_api_key") } else { apiKey = h.getAISetting(ctx, "anthropic_api_key") }
		model := h.getActiveModel(ctx, auditProvider)

		if apiKey != "" {
			// Batch translate names
			var names []string
			for _, fi := range foreignIssues { names = append(names, fi.Name) }
			translatePrompt := fmt.Sprintf(`Preložte tieto názvy kategórií do slovenčiny. Sú z e-shopového katalógu.
Zachovajte profesionálny e-commerce štýl (napr. "Detergents and cleaning" → "Čistiace prostriedky").

NÁZVY:
%s

Odpovedzte IBA JSON array v rovnakom poradí:
[{"original": "...", "slovak": "..."}]`, strings.Join(names, "\n"))

			var resp string
			var translateErr error
			if auditProvider == "openai" { resp, translateErr = callOpenAIAPIV3(translatePrompt, apiKey, model) } else { resp, translateErr = callClaudeAPIV3(translatePrompt, apiKey, model) }

			if translateErr == nil && resp != "" {
				// Parse JSON response
				resp = strings.TrimSpace(resp)
				// Find JSON array in response
				start := strings.Index(resp, "[")
				end := strings.LastIndex(resp, "]")
				if start >= 0 && end > start {
					jsonStr := resp[start : end+1]
					var translations []struct{ Original, Slovak string }
					if json.Unmarshal([]byte(jsonStr), &translations) == nil {
						transMap := map[string]string{}
						for _, t := range translations { transMap[strings.ToLower(t.Original)] = t.Slovak }
						for i := range issues {
							if issues[i].Type == "foreign" {
								if sk, ok := transMap[strings.ToLower(issues[i].Name)]; ok && sk != "" {
									issues[i].Suggestion = fmt.Sprintf("Premenovať na: \"%s\"", sk)
								}
							}
						}
					}
				}
			}
		}
	}

	// Štatistiky
	stats := map[string]int{"total": len(cats), "issues": len(issues)}
	for _, iss := range issues { stats[iss.Type]++ }

	usedProvider := provider
	if usedProvider == "" { usedProvider = h.getAISetting(ctx, "ai_provider") }
	if usedProvider == "" { usedProvider = "openai" }

	return c.JSON(fiber.Map{
		"success":  true,
		"stats":    stats,
		"issues":   issues,
		"provider": usedProvider,
	})
}

// AdminAIApplyFix — aplikuje schválenú opravu (premenovanie, mazanie, presun)
func (h *Handler) AdminAIApplyFix(c *fiber.Ctx) error {
	ctx := context.Background()
	var input struct {
		CategoryID string `json:"category_id"`
		Action     string `json:"action"` // "rename", "delete", "merge"
		NewName    string `json:"new_name"`
		MergeInto  string `json:"merge_into"` // target category ID pre merge
	}
	if err := c.BodyParser(&input); err != nil { return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neplatné údaje"}) }

	switch input.Action {
	case "rename":
		if input.NewName == "" { return c.Status(400).JSON(fiber.Map{"success": false, "error": "Nový názov je povinný"}) }
		newSlug := generateSlug(input.NewName)
		// Check slug conflict
		var exists bool
		h.db.Pool.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM categories WHERE slug = $1 AND id != $2)", newSlug, input.CategoryID).Scan(&exists)
		if exists { newSlug = newSlug + "-" + input.CategoryID[:8] }
		_, err := h.db.Pool.Exec(ctx, `UPDATE categories SET name = $1, slug = $2, updated_at = NOW() WHERE id = $3`, input.NewName, newSlug, input.CategoryID)
		if err != nil { return c.Status(500).JSON(fiber.Map{"success": false, "error": err.Error()}) }
		return c.JSON(fiber.Map{"success": true, "message": fmt.Sprintf("Premenované na \"%s\"", input.NewName)})

	case "delete":
		// Presun produkty do parent
		var parentID *string
		h.db.Pool.QueryRow(ctx, `SELECT parent_id::text FROM categories WHERE id = $1`, input.CategoryID).Scan(&parentID)
		if parentID != nil {
			h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1 WHERE category_id = $2`, *parentID, input.CategoryID)
			h.db.Pool.Exec(ctx, `UPDATE categories SET parent_id = $1 WHERE parent_id = $2`, *parentID, input.CategoryID)
		}
		_, err := h.db.Pool.Exec(ctx, `DELETE FROM categories WHERE id = $1`, input.CategoryID)
		if err != nil { return c.Status(500).JSON(fiber.Map{"success": false, "error": err.Error()}) }
		return c.JSON(fiber.Map{"success": true, "message": "Kategória zmazaná, produkty presunuté do parent"})

	case "merge":
		if input.MergeInto == "" { return c.Status(400).JSON(fiber.Map{"success": false, "error": "Cieľová kategória je povinná"}) }
		h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1 WHERE category_id = $2`, input.MergeInto, input.CategoryID)
		h.db.Pool.Exec(ctx, `UPDATE categories SET parent_id = $1 WHERE parent_id = $2`, input.MergeInto, input.CategoryID)
		h.db.Pool.Exec(ctx, `DELETE FROM categories WHERE id = $1`, input.CategoryID)
		h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
		return c.JSON(fiber.Map{"success": true, "message": "Kategórie zlúčené"})
	}

	return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neznáma akcia"})
}

// AdminAIFixAll — automaticky opraví všetky problémy v strome
func (h *Handler) AdminAIFixAll(c *fiber.Ctx) error {
	ctx := context.Background()
	provider := c.Query("provider", "")
	if provider == "" { provider = h.getAISetting(ctx, "ai_provider") }
	if provider == "" { provider = "openai" }
	apiKey := ""
	if provider == "openai" { apiKey = h.getAISetting(ctx, "openai_api_key") } else { apiKey = h.getAISetting(ctx, "anthropic_api_key") }
	model := h.getActiveModel(ctx, provider)

	var logs []string
	addLog := func(msg string) { logs = append(logs, msg) }
	renamed, deleted, merged := 0, 0, 0

	// 1. Refresh product counts
	h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)

	// 2. Delete empty leaf categories (no products, no children)
	// CHRÁNI systémové/taxonomy kategórie (created_by_shop_id IS NULL)
	for pass := 0; pass < 30; pass++ {
		h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
		res, err := h.db.Pool.Exec(ctx, `
			DELETE FROM categories
			WHERE product_count = 0
			AND created_by_shop_id IS NOT NULL
			AND NOT EXISTS (SELECT 1 FROM categories c2 WHERE c2.parent_id = categories.id)
		`)
		if err != nil { break }
		d := int(res.RowsAffected())
		deleted += d
		if d == 0 { break }
	}
	addLog(fmt.Sprintf("🗑️ Zmazaných %d prázdnych kategórií", deleted))

	// 3. Find and translate foreign category names
	if apiKey != "" {
		rows, _ := h.db.Pool.Query(ctx, `SELECT id, name FROM categories ORDER BY name`)
		type catItem struct { ID, Name string }
		var foreignCats []catItem
		slovakChars := []string{"á", "é", "í", "ó", "ú", "ý", "č", "ď", "ľ", "ň", "š", "ť", "ž", "ô", "ä"}
		foreignWords := []string{"en ", "voor ", " bij ", "van ", "met ", " and ", " for ", " with ", " the ", "und ", "für "}
		if rows != nil {
			for rows.Next() {
				var id, name string
				rows.Scan(&id, &name)
				lower := strings.ToLower(name)
				isSK := false
				for _, ch := range slovakChars {
					if strings.Contains(name, ch) { isSK = true; break }
				}
				if !isSK {
					for _, fw := range foreignWords {
						if strings.Contains(lower, fw) {
							foreignCats = append(foreignCats, catItem{id, name})
							break
						}
					}
				}
			}
			rows.Close()
		}

		if len(foreignCats) > 0 {
			addLog(fmt.Sprintf("🌍 Nájdených %d cudzích názvov, prekladám...", len(foreignCats)))

			// Batch translate (max 50 at a time)
			for start := 0; start < len(foreignCats); start += 50 {
				end := start + 50
				if end > len(foreignCats) { end = len(foreignCats) }
				batch := foreignCats[start:end]

				var names []string
				for _, fc := range batch { names = append(names, fc.Name) }

				prompt := fmt.Sprintf(`Preložte tieto názvy e-shop kategórií do slovenčiny.
Zachovajte profesionálny e-commerce štýl. Ak je názov už v slovenčine, vráťte ho bez zmeny.
NÁZVY:
%s

JSON array (rovnaké poradie):
[{"original": "...", "slovak": "..."}]`, strings.Join(names, "\n"))

				var resp string
				var err error
				if provider == "openai" { resp, err = callOpenAIAPIV3(prompt, apiKey, model) } else { resp, err = callClaudeAPIV3(prompt, apiKey, model) }

				if err == nil && resp != "" {
					s := strings.Index(resp, "[")
					e := strings.LastIndex(resp, "]")
					if s >= 0 && e > s {
						var translations []struct{ Original, Slovak string }
						if json.Unmarshal([]byte(resp[s:e+1]), &translations) == nil {
							transMap := map[string]string{}
							for _, t := range translations { transMap[t.Original] = t.Slovak }
							for _, fc := range batch {
								if sk, ok := transMap[fc.Name]; ok && sk != "" && sk != fc.Name {
									newSlug := generateSlug(sk)
									h.db.Pool.Exec(ctx, `UPDATE categories SET name = $1, slug = $2, updated_at = NOW() WHERE id = $3`, sk, newSlug, fc.ID)
									addLog(fmt.Sprintf("  ✏️ \"%s\" → \"%s\"", fc.Name, sk))
									renamed++
								}
							}
						}
					}
				}
				time.Sleep(500 * time.Millisecond)
			}
		}
	} else {
		addLog("⚠️ API kľúč nie je nastavený — preklady preskočené")
	}

	// 4. Merge exact duplicates (same name, same parent)
	dupRows, _ := h.db.Pool.Query(ctx, `
		SELECT LOWER(name), parent_id, array_agg(id ORDER BY product_count DESC) as ids, COUNT(*)
		FROM categories GROUP BY LOWER(name), parent_id HAVING COUNT(*) > 1
	`)
	if dupRows != nil {
		for dupRows.Next() {
			var lowerName string
			var parentID *string
			var ids []string
			var cnt int
			dupRows.Scan(&lowerName, &parentID, &ids, &cnt)
			if len(ids) < 2 { continue }
			keepID := ids[0]
			for _, dupID := range ids[1:] {
				h.db.Pool.Exec(ctx, `UPDATE products SET category_id = $1 WHERE category_id = $2`, keepID, dupID)
				h.db.Pool.Exec(ctx, `UPDATE categories SET parent_id = $1 WHERE parent_id = $2`, keepID, dupID)
				h.db.Pool.Exec(ctx, `DELETE FROM categories WHERE id = $1`, dupID)
				merged++
			}
			addLog(fmt.Sprintf("🔀 Zlúčené %d duplicít pre \"%s\"", cnt-1, lowerName))
		}
		dupRows.Close()
	}

	// 5. Final refresh
	h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
	h.updateCategoryProductCounts(ctx)

	return c.JSON(fiber.Map{
		"success": true,
		"message": fmt.Sprintf("Hotovo! Premenovaných: %d, Zmazaných: %d, Zlúčených: %d", renamed, deleted, merged),
		"renamed": renamed, "deleted": deleted, "merged": merged,
		"provider": provider, "logs": logs,
	})
}

func (h *Handler) AdminAICleanupShop(c *fiber.Ctx) error {
	ctx := context.Background()
	// Ensure columns exist
	h.db.Pool.Exec(ctx, `ALTER TABLE categories ADD COLUMN IF NOT EXISTS created_by_shop_id UUID`)
	h.db.Pool.Exec(ctx, `ALTER TABLE products ADD COLUMN IF NOT EXISTS created_by_shop_id UUID`)

	var input struct {
		ShopID              string `json:"shop_id"`
		DeleteProducts      bool   `json:"delete_products"`
		DeleteCategories    bool   `json:"delete_categories"`
		DeleteAllCategories bool   `json:"delete_all_categories"`
		DeleteMasterProducts bool  `json:"delete_master_products"` // Delete orphaned masters after removing offers
	}
	if err := c.BodyParser(&input); err != nil {
		return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neplatne udaje"})
	}
	if input.ShopID == "" {
		return c.Status(400).JSON(fiber.Map{"success": false, "error": "Vyberte obchod"})
	}

	var shopName string
	h.db.Pool.QueryRow(ctx, `SELECT shop_name FROM shops WHERE id = $1`, input.ShopID).Scan(&shopName)

	dp, do, dc := 0, 0, 0
	var logs []string
	addLog := func(msg string) { logs = append(logs, msg) }

	if input.DeleteProducts {
		// A) Produkty patriace tomuto vendorovi (cez created_by_shop_id)
		rows, err := h.db.Pool.Query(ctx, `SELECT id FROM products WHERE created_by_shop_id = $1`, input.ShopID)
		if err == nil {
			var pids []string
			for rows.Next() { var id string; rows.Scan(&id); pids = append(pids, id) }
			rows.Close()
			for _, pid := range pids {
				h.db.Pool.Exec(ctx, `DELETE FROM product_attributes WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM product_images WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM offers WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM products WHERE id = $1`, pid)
				dp++
			}
			addLog(fmt.Sprintf("A) %d produktov (created_by_shop_id)", dp))
		}

		// B) Produkty s offers LEN z tohto shopu (stare produkty bez created_by_shop_id)
		rows2, err2 := h.db.Pool.Query(ctx, `
			SELECT p.id FROM products p
			WHERE p.created_by_shop_id IS NULL
			AND EXISTS (SELECT 1 FROM offers o WHERE o.product_id = p.id AND o.shop_id = $1)
			AND NOT EXISTS (SELECT 1 FROM offers o2 WHERE o2.product_id = p.id AND o2.shop_id != $1)
		`, input.ShopID)
		oldCount := 0
		if err2 == nil {
			var pids2 []string
			for rows2.Next() { var id string; rows2.Scan(&id); pids2 = append(pids2, id) }
			rows2.Close()
			for _, pid := range pids2 {
				h.db.Pool.Exec(ctx, `DELETE FROM product_attributes WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM product_images WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM offers WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM products WHERE id = $1`, pid)
				oldCount++
				dp++
			}
			addLog(fmt.Sprintf("B) %d starych produktov (cez offers)", oldCount))
		}

		// C) Osirelé produkty bez offers a bez feed_id (= AI vytvorene, stary format)
		rows3, err3 := h.db.Pool.Query(ctx, `
			SELECT id FROM products
			WHERE created_by_shop_id IS NULL
			AND (feed_id IS NULL OR feed_id = '')
			AND NOT EXISTS (SELECT 1 FROM offers WHERE product_id = products.id)
		`)
		orphanCount := 0
		if err3 == nil {
			var pids3 []string
			for rows3.Next() { var id string; rows3.Scan(&id); pids3 = append(pids3, id) }
			rows3.Close()
			for _, pid := range pids3 {
				h.db.Pool.Exec(ctx, `DELETE FROM product_attributes WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM product_images WHERE product_id = $1`, pid)
				h.db.Pool.Exec(ctx, `DELETE FROM products WHERE id = $1`, pid)
				orphanCount++
				dp++
			}
			addLog(fmt.Sprintf("C) %d osirelenych produktov", orphanCount))
		}

		// D) Reset offers tohto shopu — namiesto mazania ich odpojíme od produktov
		res4, _ := h.db.Pool.Exec(ctx, `UPDATE offers SET product_id = NULL, match_type = NULL WHERE shop_id = $1`, input.ShopID)
		do = int(res4.RowsAffected())
		addLog(fmt.Sprintf("D) %d offers odpojených od produktov (pripravené na re-kategorizáciu)", do))

		// D2) Vyčisti feed cache pre čerstvý štart
		h.db.Pool.Exec(ctx, `DELETE FROM feed_category_cache`)
		addLog("D2) Feed cache vyčistený")

		// E) Zmaz master produkty bez zostávajúcich ponúk (orphaned masters)
		if input.DeleteMasterProducts {
			rows4, err4 := h.db.Pool.Query(ctx, `
				SELECT id FROM products
				WHERE NOT EXISTS (SELECT 1 FROM offers WHERE product_id = products.id)
			`)
			masterCount := 0
			if err4 == nil {
				var pids4 []string
				for rows4.Next() { var id string; rows4.Scan(&id); pids4 = append(pids4, id) }
				rows4.Close()
				for _, pid := range pids4 {
					h.db.Pool.Exec(ctx, `DELETE FROM product_attributes WHERE product_id = $1`, pid)
					h.db.Pool.Exec(ctx, `DELETE FROM product_images WHERE product_id = $1`, pid)
					h.db.Pool.Exec(ctx, `DELETE FROM products WHERE id = $1`, pid)
					masterCount++
					dp++
				}
				addLog(fmt.Sprintf("E-master) %d master produktov bez ponúk zmazaných", masterCount))
			}
		}
	}

	// Update offer_count on remaining products
	h.db.Pool.Exec(ctx, `
		UPDATE products SET offer_count = (SELECT COUNT(*) FROM offers WHERE product_id = products.id)
	`)

	// Refresh product_count
	h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)

	// Mazanie kategorii
	if input.DeleteAllCategories {
		// Zmaz VŠETKY prázdne kategórie (leaf nodes bez produktov)
		for pass := 0; pass < 30; pass++ {
			h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
			res, err := h.db.Pool.Exec(ctx, `
				DELETE FROM categories
				WHERE product_count = 0
				AND NOT EXISTS (SELECT 1 FROM categories c2 WHERE c2.parent_id = categories.id)
			`)
			if err != nil { addLog(fmt.Sprintf("E) SQL error: %v", err)); break }
			deleted := int(res.RowsAffected())
			dc += deleted
			if deleted == 0 { break }
		}
		addLog(fmt.Sprintf("E) %d kategorii zmazanych (všetky prázdne)", dc))
	} else if input.DeleteCategories {
		// Zmaz len prázdne kategórie vytvorené týmto vendorom
		for pass := 0; pass < 30; pass++ {
			h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
			res, err := h.db.Pool.Exec(ctx, `
				DELETE FROM categories
				WHERE product_count = 0
				AND NOT EXISTS (SELECT 1 FROM categories c2 WHERE c2.parent_id = categories.id)
				AND created_by_shop_id = $1
			`, input.ShopID)
			if err != nil { addLog(fmt.Sprintf("E) SQL error: %v", err)); break }
			deleted := int(res.RowsAffected())
			dc += deleted
			if deleted == 0 { break }
		}
		addLog(fmt.Sprintf("E) %d prázdnych kategorii zmazanych", dc))
	}

	// Final refresh
	h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
	h.updateCategoryProductCounts(ctx)

	return c.JSON(fiber.Map{
		"success": true,
		"message": fmt.Sprintf("Vycistene pre %s: %d produktov, %d ponuk, %d kategorii", shopName, dp, do, dc),
		"products": dp, "offers": do, "categories": dc, "logs": logs,
	})
}

// ============================================================
// AI TEST CONNECTION
// ============================================================

func (h *Handler) AdminAITestConnection(c *fiber.Ctx) error {
	ctx := context.Background()
	provider := c.Query("provider", "")
	if provider == "" { provider = h.getAISetting(ctx, "ai_provider") }
	if provider == "" { provider = "openai" }

	apiKey := ""
	if provider == "openai" { apiKey = h.getAISetting(ctx, "openai_api_key") } else { apiKey = h.getAISetting(ctx, "anthropic_api_key") }
	model := h.getActiveModel(ctx, provider)

	if apiKey == "" {
		return c.JSON(fiber.Map{
			"success": false, "error": fmt.Sprintf("API kľúč pre %s nie je nastavený! Nastav ho v AI Nastaveniach.", provider),
			"provider": provider, "model": model, "key_set": false,
		})
	}

	// Test with simple categorization prompt
	testPrompt := `Zaraď produkt "Samsung Galaxy S24 128GB čierny" do e-shop kategórie.
Odpovedz IBA JSON: {"category_path": ["Elektronika", "Mobilné telefóny", "Smartfóny"], "brand": "Samsung"}`

	var resp string
	var err error
	start := time.Now()
	if provider == "openai" { resp, err = callOpenAIAPIV3(testPrompt, apiKey, model) } else { resp, err = callClaudeAPIV3(testPrompt, apiKey, model) }
	elapsed := time.Since(start)

	if err != nil {
		return c.JSON(fiber.Map{
			"success": false, "error": fmt.Sprintf("AI API chyba: %v", err),
			"provider": provider, "model": model, "key_set": true, "key_preview": apiKey[:8] + "...",
		})
	}

	return c.JSON(fiber.Map{
		"success": true, "message": fmt.Sprintf("✅ %s API funguje! Model: %s, Odozva: %dms", provider, model, elapsed.Milliseconds()),
		"provider": provider, "model": model, "response": resp, "elapsed_ms": elapsed.Milliseconds(),
		"key_set": true, "key_preview": apiKey[:8] + "...",
	})
}

// ============================================================
// SMART RE-CATEGORIZE — AI mapuje feed kategórie na CPC cesty
// ============================================================

func (h *Handler) AdminAISmartRecategorize(c *fiber.Ctx) error {
	ctx := context.Background()
	action := c.Query("action", "analyze") // analyze, preview, apply

	// ============ PHASE 1: ANALYZE — zozbiera unikátne feed kategórie ============
	if action == "analyze" {
		rows, err := h.db.Pool.Query(ctx, `
			SELECT DISTINCT o.category, COUNT(*) as cnt
			FROM offers o 
			WHERE o.category IS NOT NULL AND o.category != ''
			GROUP BY o.category
			ORDER BY cnt DESC
		`)
		if err != nil { return c.Status(500).JSON(fiber.Map{"success": false, "error": err.Error()}) }
		defer rows.Close()

		type feedCat struct {
			Feed     string `json:"feed"`
			Count    int    `json:"count"`
			Current  string `json:"current_path"`
		}
		var feeds []feedCat
		for rows.Next() {
			var fc feedCat
			rows.Scan(&fc.Feed, &fc.Count)
			feeds = append(feeds, fc)
		}

		// Get current mapping (what categories products with this feed are in)
		for i, fc := range feeds {
			var currentPath string
			h.db.Pool.QueryRow(ctx, `
				SELECT COALESCE(
					(SELECT string_agg(name, ' > ' ORDER BY level) FROM (
						WITH RECURSIVE cat_tree AS (
							SELECT id, name, parent_id, 0 as level FROM categories WHERE id = p.category_id
							UNION ALL
							SELECT c.id, c.name, c.parent_id, ct.level + 1 FROM categories c JOIN cat_tree ct ON ct.parent_id = c.id
						) SELECT name, level FROM cat_tree ORDER BY level DESC
					) sub), ''
				)
				FROM offers o JOIN products p ON o.product_id = p.id
				WHERE o.category = $1 AND p.category_id IS NOT NULL
				LIMIT 1
			`, fc.Feed).Scan(&currentPath)
			feeds[i].Current = currentPath
		}

		// Get existing root categories
		var roots []string
		rootRows, _ := h.db.Pool.Query(ctx, `SELECT name FROM categories WHERE parent_id IS NULL ORDER BY name`)
		if rootRows != nil {
			for rootRows.Next() {
				var n string
				rootRows.Scan(&n)
				roots = append(roots, n)
			}
			rootRows.Close()
		}

		return c.JSON(fiber.Map{
			"success":        true,
			"feeds":          feeds,
			"total_feeds":    len(feeds),
			"existing_roots": roots,
		})
	}

	// ============ PHASE 2: PREVIEW — AI mapuje feed kategórie ============
	if action == "preview" {
		var input struct {
			Provider string   `json:"provider"`
			Feeds    []string `json:"feeds"` // feed categories to map
		}
		if err := c.BodyParser(&input); err != nil { return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neplatné údaje"}) }

		provider := input.Provider
		if provider == "" { provider = h.getAISetting(ctx, "ai_provider") }
		if provider == "" { provider = "openai" }
		apiKey := ""
		if provider == "openai" { apiKey = h.getAISetting(ctx, "openai_api_key") } else { apiKey = h.getAISetting(ctx, "anthropic_api_key") }
		model := h.getActiveModel(ctx, provider)

		if apiKey == "" {
			return c.Status(400).JSON(fiber.Map{"success": false, "error": fmt.Sprintf("API kľúč pre %s nie je nastavený!", provider)})
		}

		// Get existing root categories
		var roots []string
		rootRows, _ := h.db.Pool.Query(ctx, `SELECT name FROM categories WHERE parent_id IS NULL ORDER BY name`)
		if rootRows != nil {
			for rootRows.Next() { var n string; rootRows.Scan(&n); roots = append(roots, n) }
			rootRows.Close()
		}

		type mapping struct {
			Feed       string   `json:"feed"`
			Suggested  []string `json:"suggested"`
			SuggestedStr string `json:"suggested_str"`
			Reasoning  string   `json:"reasoning"`
		}
		var results []mapping

		// Process in batches of 25
		batchSize := 25
		for start := 0; start < len(input.Feeds); start += batchSize {
			end := start + batchSize
			if end > len(input.Feeds) { end = len(input.Feeds) }
			batch := input.Feeds[start:end]

			var feedList string
			for i, f := range batch {
				feedList += fmt.Sprintf("%d. %s\n", i+1, f)
			}

			prompt := fmt.Sprintf(`Si profesionálny kategorizačný systém pre slovenský CPC porovnávač cien MegaPrice.sk.

EXISTUJÚCE ROOT KATEGÓRIE v e-shope:
%s

ÚLOHA: Pre každú feed kategóriu navrhni IDEÁLNU cestu v slovenskom e-shope.

PRAVIDLÁ:
1. Používaj EXISTUJÚCE root kategórie ak to dáva zmysel
2. Vytváraj LOGICKÚ hierarchiu (max 4 úrovne)
3. VŠETKO v slovenčine - profesionálny e-commerce štýl
4. "Ruža"/"Overig" = "Ostatné" (chybný preklad z holandčiny)
5. "Kuchynské spôsoby" = "Kuchynské náčinie" (chybný preklad "Kookgerei")
6. "Služba" = "Servis" alebo "Príbory a taniere" (chybný preklad "Servies")
7. "Úľava" = "Osvetlenie" (chybný preklad "Verlichting")  
8. "Riad" patrí pod "Kuchynské potreby" nie priamo pod "Dom a záhrada"
9. "Batérie/Nabíjačky" patria pod "Elektronika", NIE pod "Hračky"
10. Logicky preskupuj - nie len kopíruj feed cestu!

FEED KATEGÓRIE NA MAPOVANIE:
%s

Odpovedz IBA JSON array (rovnaké poradie):
[
  {"feed": "...", "path": ["Root", "Sub", "SubSub"], "reason": "krátke vysvetlenie"}
]`, strings.Join(roots, ", "), feedList)

			var resp string
			var callErr error
			if provider == "openai" { resp, callErr = callOpenAIAPIV3(prompt, apiKey, model) } else { resp, callErr = callClaudeAPIV3(prompt, apiKey, model) }

			if callErr != nil {
				return c.JSON(fiber.Map{"success": false, "error": fmt.Sprintf("AI chyba pri batch %d: %v", start/batchSize+1, callErr), "partial_results": results})
			}

			// Parse JSON response
			resp = strings.TrimSpace(resp)
			s := strings.Index(resp, "[")
			e := strings.LastIndex(resp, "]")
			if s >= 0 && e > s {
				var parsed []struct {
					Feed   string   `json:"feed"`
					Path   []string `json:"path"`
					Reason string   `json:"reason"`
				}
				if json.Unmarshal([]byte(resp[s:e+1]), &parsed) == nil {
					for _, p := range parsed {
						if len(p.Path) > 0 {
							results = append(results, mapping{
								Feed:        p.Feed,
								Suggested:   p.Path,
								SuggestedStr: strings.Join(p.Path, " > "),
								Reasoning:   p.Reason,
							})
						}
					}
				} else {
					return c.JSON(fiber.Map{"success": false, "error": "AI vrátila neplatný JSON", "raw": resp[s:e+1], "partial_results": results})
				}
			}

			time.Sleep(500 * time.Millisecond)
		}

		return c.JSON(fiber.Map{
			"success":  true,
			"mappings": results,
			"total":    len(results),
			"provider": provider,
			"model":    model,
		})
	}

	// ============ PHASE 3: APPLY — aplikuje mapovanie ============
	if action == "apply" {
		var input struct {
			Mappings []struct {
				Feed     string   `json:"feed"`
				Path     []string `json:"path"`
			} `json:"mappings"`
		}
		if err := c.BodyParser(&input); err != nil { return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neplatné údaje"}) }

		var logs []string
		updated, created, errors := 0, 0, 0

		// Load existing categories
		existingCats := h.getExistingCategoryTree(ctx)

		for _, m := range input.Mappings {
			if len(m.Path) == 0 || m.Feed == "" { continue }

			// Find or create the target category path
			categoryID := h.findOrCreateCategoryPath(ctx, m.Path, &existingCats, "")

			if categoryID == "" {
				logs = append(logs, fmt.Sprintf("❌ Nepodarilo sa vytvoriť cestu: %s", strings.Join(m.Path, " > ")))
				errors++
				continue
			}

			// Update all products that have offers with this feed category
			res, err := h.db.Pool.Exec(ctx, `
				UPDATE products SET category_id = $1, updated_at = NOW()
				WHERE id IN (
					SELECT DISTINCT p.id FROM products p
					JOIN offers o ON o.product_id = p.id
					WHERE o.category = $2
				)
			`, categoryID, m.Feed)

			if err != nil {
				logs = append(logs, fmt.Sprintf("❌ Chyba pre '%s': %v", m.Feed, err))
				errors++
			} else {
				n := int(res.RowsAffected())
				updated += n
				if n > 0 {
					logs = append(logs, fmt.Sprintf("✅ '%s' → '%s' (%d produktov)", m.Feed, strings.Join(m.Path, " > "), n))
				}
				created++
			}
		}

		// Refresh category product counts
		h.db.Pool.Exec(ctx, `UPDATE categories SET product_count = (SELECT COUNT(*) FROM products WHERE category_id = categories.id)`)
		h.updateCategoryProductCounts(ctx)

		// Clean up empty categories
		for pass := 0; pass < 10; pass++ {
			res, _ := h.db.Pool.Exec(ctx, `
				DELETE FROM categories WHERE product_count = 0
				AND NOT EXISTS (SELECT 1 FROM categories c2 WHERE c2.parent_id = categories.id)
			`)
			if res.RowsAffected() == 0 { break }
		}

		return c.JSON(fiber.Map{
			"success":  true,
			"message":  fmt.Sprintf("Aplikované! %d mapovaní, %d produktov aktualizovaných, %d chýb", created, updated, errors),
			"updated":  updated,
			"mappings": created,
			"errors":   errors,
			"logs":     logs,
		})
	}

	return c.Status(400).JSON(fiber.Map{"success": false, "error": "Neznáma akcia. Použite: analyze, preview, apply"})
}
